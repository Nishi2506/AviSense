---
name: Obsidian Flight Ops
colors:
  surface: '#121414'
  surface-dim: '#121414'
  surface-bright: '#38393a'
  surface-container-lowest: '#0d0e0f'
  surface-container-low: '#1a1c1c'
  surface-container: '#1e2020'
  surface-container-high: '#292a2a'
  surface-container-highest: '#343535'
  on-surface: '#e3e2e2'
  on-surface-variant: '#bbcabf'
  inverse-surface: '#e3e2e2'
  inverse-on-surface: '#2f3131'
  outline: '#86948a'
  outline-variant: '#3c4a42'
  surface-tint: '#4edea3'
  primary: '#4edea3'
  on-primary: '#003824'
  primary-container: '#10b981'
  on-primary-container: '#00422b'
  inverse-primary: '#006c49'
  secondary: '#ffb95f'
  on-secondary: '#472a00'
  secondary-container: '#ee9800'
  on-secondary-container: '#5b3800'
  tertiary: '#ffb3ad'
  on-tertiary: '#68000a'
  tertiary-container: '#ff7a73'
  on-tertiary-container: '#79000e'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#6ffbbe'
  primary-fixed-dim: '#4edea3'
  on-primary-fixed: '#002113'
  on-primary-fixed-variant: '#005236'
  secondary-fixed: '#ffddb8'
  secondary-fixed-dim: '#ffb95f'
  on-secondary-fixed: '#2a1700'
  on-secondary-fixed-variant: '#653e00'
  tertiary-fixed: '#ffdad7'
  tertiary-fixed-dim: '#ffb3ad'
  on-tertiary-fixed: '#410004'
  on-tertiary-fixed-variant: '#930013'
  background: '#121414'
  on-background: '#e3e2e2'
  surface-variant: '#343535'
typography:
  headline-xl:
    fontFamily: Inter
    fontSize: 36px
    fontWeight: '600'
    lineHeight: 44px
    letterSpacing: -0.02em
  headline-xl-mobile:
    fontFamily: Inter
    fontSize: 28px
    fontWeight: '600'
    lineHeight: 34px
    letterSpacing: -0.01em
  headline-lg:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: -0.015em
  headline-lg-mobile:
    fontFamily: Inter
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '500'
    lineHeight: 24px
    letterSpacing: -0.01em
  body-lg:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
    letterSpacing: 0em
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
    letterSpacing: 0em
  body-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
    letterSpacing: 0.01em
  label-lg:
    fontFamily: JetBrains Mono
    fontSize: 14px
    fontWeight: '500'
    lineHeight: 20px
    letterSpacing: 0.02em
  label-md:
    fontFamily: JetBrains Mono
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.04em
  label-sm:
    fontFamily: JetBrains Mono
    fontSize: 10px
    fontWeight: '500'
    lineHeight: 14px
    letterSpacing: 0.06em
  metric-display:
    fontFamily: JetBrains Mono
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 38px
    letterSpacing: -0.03em
  metric-display-mobile:
    fontFamily: JetBrains Mono
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 30px
    letterSpacing: -0.02em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  gutter: 1rem
  gutter-desktop: 1.5rem
  margin: 1rem
  margin-desktop: 2rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
---

## Brand & Style

This design system targets mission-critical flight dispatchers, avionics telemetry engineers, and fleet operations directors operating in low-light command centers. The brand voice is austere, hyper-precise, and uncompromisingly utilitarian. The interface avoids frivolous ornamentation, neon skeuomorphism, and faux-tactical "gaming HUD" artifacts in favor of pure operational legibility and rapid signal detection.

The aesthetic fuses **Precision Minimalism** with an **Architectonic Dark Protocol**:
- Absolute jet-black and obsidian surfaces preserve night vision and eliminate monitor bezel glare.
- High-contrast monochromatic typography delivers instantaneous scanning of tail numbers, transponder coordinates, and NOTAM updates.
- Semantic color is strictly rationed: status hues appear only to communicate state, operational variance, and real-time risk tiers.

## Colors

The palette is engineered for pure contrast against true pitch dark. Backgrounds layer strictly from `#000000` (deep canvas base) to `#0a0a0a` (structural card containers) and `#111111` (elevated inspection panels, popovers, and selected table rows). Hairline structural boundaries use `#1f1f1f` and `#222222` to delineate regions without competing with data.

Accent colors function solely as telemetry indicators:
- **Primary / Low Risk / Nominal (`#10b981`)**: Airworthy status, active transponders, verified flight plans, and nominal telemetry.
- **Secondary / Advisory / Medium Risk (`#f59e0b`)**: Weather holds, non-critical maintenance flags, holding patterns, and minor schedule deviations.
- **Tertiary / Critical / High Risk (`#ef4444`)**: Fuel emergencies, airspace breaches, engine master cautions, and immediate collision alerts.
- **Text & Monochromatic Metrics**: Canvas text defaults to pure white (`#ffffff`) for active readings and crisp neutral gray (`#a3a3a3`) for units, secondary labels, and metadata. Inactive states rely on `#525252`.

## Typography

The typographic hierarchy prioritizes rapid scanning and tabular data alignment:
- **Inter** provides objective, neutral clarity across operational views, flight rosters, and dispatch directives. Its tall x-height and clear apertures avoid glyph confusion in low-light operation.
- **JetBrains Mono** serves all avionics coordinates, ICAO/IATA identifiers, altitudes, Mach numbers, timestamps (UTC/Zulu), and telemetry metrics. Tabular figures ensure numerical readouts do not jitter during real-time data streaming.
- Monospaced labels use explicit positive tracking (`0.02em` to `0.06em`) to preserve legibility when rendered in dense telemetry sidebars or compact Streamlit metric blocks.

## Layout & Spacing

Layouts adhere to an analytical fixed-density fluid grid system:
- **Multi-Monitor Operations**: 12-column responsive layout spanning up to `1920px` max canvas width, collapsing into an 8-column layout for tablets and a 4-column single-stream view on emergency field tablets or mobile devices.
- **Rhythm**: All layout gaps, metric tiles, and control toolbars align to an exact 4px/8px modular base scale.
- **Density Management**: Streamlit sidebar panels retain a consistent width (`320px` desktop) dedicated to parameter filters, sector selection, and alert feeds. The main canvas arranges primary telemetry maps and dataframes with tight, uniform `1.5rem` gutters.
- **Generous Canvas Margins**: Outer bounds maintain a deliberate `2rem` margin on desktop to frame data clearly against surrounding hardware bezels without accidental clipping.

## Elevation & Depth

This system intentionally rejects skeuomorphic drop shadows, bloom effects, and ambient light glows. All visual depth is strictly architectural, relying on planar tonal stepping and micro-borders:

- **Surface 0 (Base Canvas / Shell)**: `#000000` (deepest black).
- **Surface 1 (Card & Section Containers)**: `#0a0a0a` bounded by a 1px solid border of `#1f1f1f`.
- **Surface 2 (Interactive Rows, Modals & Inspection Drawers)**: `#111111` bounded by a 1px solid border of `#222222`.
- **Surface 3 (Overlays, Tooltips & Quick-Action Menus)**: `#171717` bounded by a 1px solid border of `#2e2e2e`.

Transitions between elevation tiers rely on pure color steps rather than shadow casting. When an element hovers or shifts state, the border illumination shifts from `#1f1f1f` to `#333333`, reinforcing precision rather than physical altitude.

## Shapes

The design system enforces a restrained soft-geometry philosophy (`roundedness: 1`):
- Standard control elements, inputs, metric pods, and table cells utilize a tight `0.25rem` (4px) border radius.
- Larger operational panels and Streamlit metric containers utilize `rounded-lg` (`0.5rem` / 8px).
- Status pips and active transponder indicators use full geometric circles (`50%`), whereas status chips and tags retain the exact same `0.25rem` corner radius as primary inputs to ensure an uncompromising, industrial instrument aesthetic.
- Sharp internal dividers (`0px` radius) maintain clean vertical and horizontal segmentation across flight rosters.

## Components

### Buttons & Interactive Controls
- **Primary Action (Commit / Dispatch)**: Background `#ffffff`, text `#000000`, weight 500, radius 4px. On hover: background `#e5e5e5`. Focus: 1px outline in `#ffffff` offset by 2px in `#000000`.
- **Secondary Action (Inspect / Filter)**: Background `#0a0a0a`, 1px border `#222222`, text `#ffffff`. On hover: border `#383838`, background `#111111`.
- **Destructive / Abort Action**: Background `#180b0b`, 1px border `#ef4444`, text `#ef4444`. On hover: background `#ef4444`, text `#ffffff`.

### Telemetry & Risk Chips
- Compact, flat layout with zero drop shadow.
- Height: 22px, padding: `2px 8px`, typography: `label-sm` (`JetBrains Mono`).
- **Nominal / Low Risk**: Background `#051d14`, border `1px solid #10b981`, text `#10b981`.
- **Advisory / Medium Risk**: Background `#1f1505`, border `1px solid #f59e0b`, text `#f59e0b`.
- **Critical / High Risk**: Background `#200808`, border `1px solid #ef4444`, text `#ef4444`.
- **Neutral / En Route**: Background `#141414`, border `1px solid #262626`, text `#a3a3a3`.

### Data Tables & Flight Rosters
- Header: `#0a0a0a`, bottom border 1px `#222222`, typography `label-sm` in `#737373`, uppercase.
- Row items: Height 36px, alternate striping disabled (all rows `#000000` or `#0a0a0a`), row separation handled via 1px `#1a1a1a` horizontal rules.
- Hover state: Row background changes to `#141414` with zero vertical layout shifting.
- Cell alignment: Monospaced numerical values right-aligned; flight designators and sector names left-aligned.

### Input Fields & Streamlit Widgets
- Background: `#0a0a0a`, border: `1px solid #222222`, height: 36px, text: `#ffffff`.
- Placeholder text: `#525252`.
- Focus state: Border transition to `#525252`. No glowing drop shadow or box shadow ring.
- Streamlit selectboxes, sliders, and date pickers use `#111111` for popover containers with `#222222` perimeter framing.

### Operational Metric Pods (KPI Displays)
- Background: `#0a0a0a`, border: `1px solid #1f1f1f`, internal padding: `space-md` (`1rem`).
- Label: `label-md` in `#a3a3a3`.
- Primary Value: `metric-display` in `#ffffff`.
- Delta / Status: Displayed directly below value using `label-sm` combined with a non-glowing semantic dot indicator (`6px` solid circle).