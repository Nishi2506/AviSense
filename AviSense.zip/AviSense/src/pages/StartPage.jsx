import React, { useEffect, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useApp } from '../context/AppContext';
import { EPISODES } from '../data/mockData';
import './StartPage.css';

export default function StartPage() {
  const navigate = useNavigate();
  const {
    selectedCamera,
    systemState,
    startRun,
    stopToStandby,
    calibProgress,
    calibStep,
    feedTimerText,
    medThreshold,
    highThreshold,
    setSelectedEpisodeId
  } = useApp();

  const [jitter1, setJitter1] = useState({ x: 0, y: 0 });
  const [jitter2, setJitter2] = useState({ x: 0, y: 0 });
  const [jitter3, setJitter3] = useState({ x: 0, y: 0 });

  useEffect(() => {
    let interval = null;
    if (systemState === 'LIVE') {
      interval = setInterval(() => {
        setJitter1({
          x: (Math.random() - 0.5) * 4,
          y: (Math.random() - 0.5) * 4
        });
        setJitter2({
          x: (Math.random() - 0.5) * 5,
          y: (Math.random() - 0.5) * 3
        });
        setJitter3({
          x: (Math.random() - 0.5) * 6,
          y: (Math.random() - 0.5) * 4
        });
      }, 800);
    }
    return () => {
      if (interval) clearInterval(interval);
    };
  }, [systemState]);

  const recentEpisodes = EPISODES.slice(0, 4);

  const handleInspectEpisode = (epId) => {
    setSelectedEpisodeId(epId);
    navigate('/alerts');
  };

  return (
    <div className="flex flex-col w-full start-page-container">
      {/* Operational Sub-Header & Status Ribbon */}
      <section className="flex flex-col md:flex-row md:items-center justify-between gap-space-md pb-space-lg mb-space-lg border-b border-outline-variant/30">
        <div className="flex flex-col gap-space-xs">
          <div className="flex items-center gap-2">
            <span className="font-label-sm text-label-sm text-outline uppercase tracking-wider">
              Terminal Operational Sector
            </span>
            <span className="text-outline-variant">/</span>
            <span className="font-label-sm text-label-sm text-primary tracking-wide" id="sector-grid-tag">
              {selectedCamera.grid}
            </span>
          </div>
          <div className="flex items-baseline gap-space-md">
            <h2 className="font-headline-lg text-headline-lg text-on-surface tracking-tight font-semibold" id="view-runway-title">
              {selectedCamera.name} <span className="text-outline font-normal">| {selectedCamera.airport}</span>
            </h2>
            <span className="font-label-md text-label-md text-on-surface-variant font-medium">
              {selectedCamera.airportName}
            </span>
          </div>
        </div>
        <div className="flex items-center gap-space-md">
          <div className="flex items-center gap-2 px-3 py-1.5 rounded-DEFAULT bg-surface-container-low border border-outline-variant/30 font-label-sm text-label-sm">
            <span className="text-outline">SYSTEM:</span>
            {systemState === 'STANDBY' && (
              <span className="text-primary font-medium flex items-center gap-1">
                <span className="w-2 h-2 rounded-full bg-primary animate-pulse"></span> READY FOR ACQUISITION
              </span>
            )}
            {systemState === 'CALIBRATING' && (
              <span className="text-secondary font-medium flex items-center gap-1">
                <span className="w-2 h-2 rounded-full bg-secondary animate-pulse"></span> CALIBRATING SENSOR
              </span>
            )}
            {systemState === 'LIVE' && (
              <span className="text-primary font-medium flex items-center gap-1">
                <span className="w-2 h-2 rounded-full bg-primary animate-pulse"></span> TELEMETRY STREAM ACQUIRED
              </span>
            )}
          </div>
        </div>
      </section>

      {/* Section 1: Executive Operations Overview & System Architecture Metrics */}
      <section className="flex flex-col gap-space-md mb-space-xl">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-space-md">
          {/* Spec 1: 5 Evaluated Telemetry Factors */}
          <div className="p-space-md bg-surface-container-low border border-outline-variant/30 rounded-DEFAULT flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between mb-space-xs">
                <span className="font-label-sm text-label-sm text-outline uppercase tracking-wider">Metric Matrix</span>
                <span className="font-label-sm text-label-sm text-primary font-semibold">05 VECTORS</span>
              </div>
              <h3 className="font-headline-sm text-headline-sm text-on-surface font-medium mb-space-xs">5 Risk Factors Evaluated</h3>
              <p className="font-body-sm text-body-sm text-on-surface-variant mb-space-md">Real-time dynamic synthesis across high-priority flight hazard vectors.</p>
            </div>
            <div className="flex flex-wrap gap-1 border-t border-outline-variant/20 pt-space-sm">
              <span className="px-2 py-0.5 bg-surface-container text-on-surface-variant font-label-sm text-label-sm rounded-DEFAULT border border-outline-variant/20">Proximity</span>
              <span className="px-2 py-0.5 bg-surface-container text-on-surface-variant font-label-sm text-label-sm rounded-DEFAULT border border-outline-variant/20">Count</span>
              <span className="px-2 py-0.5 bg-surface-container text-on-surface-variant font-label-sm text-label-sm rounded-DEFAULT border border-outline-variant/20">Flock Size</span>
              <span className="px-2 py-0.5 bg-surface-container text-on-surface-variant font-label-sm text-label-sm rounded-DEFAULT border border-outline-variant/20">Velocity</span>
              <span className="px-2 py-0.5 bg-surface-container text-on-surface-variant font-label-sm text-label-sm rounded-DEFAULT border border-outline-variant/20">Time of Day</span>
            </div>
          </div>

          {/* Spec 2: Threshold Escalation Matrix */}
          <div className="p-space-md bg-surface-container-low border border-outline-variant/30 rounded-DEFAULT flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between mb-space-xs">
                <span className="font-label-sm text-label-sm text-outline uppercase tracking-wider">Classification</span>
                <span className="font-label-sm text-label-sm text-on-surface font-semibold">SIG-RULE 4.2</span>
              </div>
              <h3 className="font-headline-sm text-headline-sm text-on-surface font-medium mb-space-xs">Risk Scoring Protocol</h3>
              <p className="font-body-sm text-body-sm text-on-surface-variant mb-space-md">Automated threat categorisation based on cumulative telemetry calculation.</p>
            </div>
            <div className="grid grid-cols-3 gap-1 border-t border-outline-variant/20 pt-space-sm font-label-sm text-label-sm">
              <div className="flex flex-col px-2 py-1 bg-surface-container rounded-DEFAULT border border-outline-variant/20">
                <span className="text-primary font-medium">LOW</span>
                <span className="text-on-surface-variant">&lt; {medThreshold.toFixed(2)}</span>
              </div>
              <div className="flex flex-col px-2 py-1 bg-surface-container rounded-DEFAULT border border-outline-variant/20">
                <span className="text-secondary font-medium">MEDIUM</span>
                <span className="text-on-surface-variant">{medThreshold.toFixed(2)}–{highThreshold.toFixed(2)}</span>
              </div>
              <div className="flex flex-col px-2 py-1 bg-surface-container rounded-DEFAULT border border-outline-variant/20">
                <span className="text-error font-medium">HIGH</span>
                <span className="text-on-surface-variant">≥ {highThreshold.toFixed(2)}</span>
              </div>
            </div>
          </div>

          {/* Spec 3: Target CV Pipeline */}
          <div className="p-space-md bg-surface-container-low border border-outline-variant/30 rounded-DEFAULT flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between mb-space-xs">
                <span className="font-label-sm text-label-sm text-outline uppercase tracking-wider">Inference Chain</span>
                <span className="font-label-sm text-label-sm text-primary font-semibold">120 FPS CAP</span>
              </div>
              <h3 className="font-headline-sm text-headline-sm text-on-surface font-medium mb-space-xs">Target Pipeline</h3>
              <p className="font-body-sm text-body-sm text-on-surface-variant mb-space-md">End-to-end hardware-accelerated computer vision stream processing.</p>
            </div>
            <div className="flex items-center justify-between border-t border-outline-variant/20 pt-space-sm font-label-sm text-label-sm text-on-surface-variant">
              <span className="font-medium text-on-surface">Ingest</span>
              <span className="material-symbols-outlined text-[12px] text-outline">arrow_forward</span>
              <span className="font-medium text-on-surface">YOLOv8</span>
              <span className="material-symbols-outlined text-[12px] text-outline">arrow_forward</span>
              <span className="font-medium text-on-surface">DeepSORT</span>
              <span className="material-symbols-outlined text-[12px] text-outline">arrow_forward</span>
              <span className="font-medium text-primary">Telemetry</span>
            </div>
          </div>
        </div>
      </section>

      {/* Section 2: Interactive Video Monitoring Container (Standby / Calibrating / Live Active) */}
      <section className="mb-space-xl">
        <div className="relative w-full bg-surface-container-low border border-outline-variant/30 rounded-DEFAULT overflow-hidden min-h-[440px] flex flex-col justify-between transition-colors">
          {/* STATE A: STANDBY IDLE VIEW */}
          {systemState === 'STANDBY' && (
            <div className="absolute inset-0 flex flex-col items-center justify-center p-space-xl z-20 transition-opacity duration-300">
              {/* Background SVG Calibration Pattern */}
              <div className="absolute inset-0 opacity-15 pointer-events-none flex items-center justify-center">
                <svg className="w-full h-full" fill="none" viewBox="0 0 800 400" xmlns="http://www.w3.org/2000/svg">
                  <defs>
                    <pattern height="40" id="runway-grid" patternUnits="userSpaceOnUse" width="40">
                      <path className="text-outline-variant" d="M 40 0 L 0 0 0 40" fill="none" stroke="currentColor" strokeWidth="0.5"></path>
                    </pattern>
                  </defs>
                  <rect fill="url(#runway-grid)" height="100%" width="100%"></rect>
                  <circle className="text-outline" cx="400" cy="200" r="140" stroke="currentColor" strokeDasharray="4 4" strokeWidth="0.75"></circle>
                  <circle className="text-outline" cx="400" cy="200" r="80" stroke="currentColor" strokeWidth="0.75"></circle>
                  <circle className="text-primary" cx="400" cy="200" fill="currentColor" r="6"></circle>
                  <line className="text-outline" stroke="currentColor" strokeWidth="0.5" x1="160" x2="640" y1="200" y2="200"></line>
                  <line className="text-outline" stroke="currentColor" strokeWidth="0.5" x1="400" x2="400" y1="40" y2="360"></line>
                  <text className="text-on-surface-variant font-label-sm text-[10px]" fill="currentColor" x="410" y="70">39°51'42"N</text>
                  <text className="text-on-surface-variant font-label-sm text-[10px]" fill="currentColor" x="410" y="340">104°40'23"W</text>
                  <text className="text-on-surface-variant font-label-sm text-[10px]" fill="currentColor" x="180" y="190">AZ 180°</text>
                  <text className="text-on-surface-variant font-label-sm text-[10px]" fill="currentColor" x="590" y="190">ELEV 5,431 FT</text>
                </svg>
              </div>

              {/* Foreground Standby Card */}
              <div className="relative z-10 flex flex-col items-center text-center max-w-xl">
                <div className="w-12 h-12 bg-surface-container border border-outline-variant/40 rounded-DEFAULT flex items-center justify-center text-primary mb-space-md">
                  <span className="material-symbols-outlined text-[24px]">videocam</span>
                </div>
                <div className="flex items-center gap-2 mb-space-xs">
                  <span className="w-1.5 h-1.5 bg-outline rounded-full"></span>
                  <span className="font-label-sm text-label-sm text-outline uppercase tracking-wider">SENSOR STANDBY MODE</span>
                </div>
                <h3 className="font-headline-lg text-headline-lg text-on-surface font-semibold mb-space-xs">
                  Ready to Begin Monitoring
                </h3>
                <p className="font-body-md text-body-md text-on-surface-variant mb-space-lg leading-relaxed">
                  Select a video source and start time in the sidebar controls, then click ‘Run’ to initialize target detection and real-time risk assessment.
                </p>

                {/* Functional Trigger Buttons */}
                <div className="flex flex-col sm:flex-row items-center gap-space-sm w-full justify-center">
                  <button
                    onClick={startRun}
                    className="btn-idle-glow h-10 px-space-xl bg-primary text-on-primary font-label-md text-label-md font-semibold rounded-DEFAULT hover:bg-primary-fixed hover:scale-105 active:scale-95 transition-all flex items-center justify-center gap-2 cursor-pointer shadow-lg"
                    type="button"
                  >
                    <span className="material-symbols-outlined text-[18px]">play_circle</span>
                    Initialize Run
                  </button>
                  <div className="h-10 px-space-md bg-surface-container border border-outline-variant/30 rounded-DEFAULT flex items-center gap-2 text-on-surface-variant font-label-sm text-label-sm">
                    <span className="material-symbols-outlined text-[16px] text-outline">tune</span>
                    <span>Source: {selectedCamera.label.split(' - ')[0]} • Thresh: {medThreshold.toFixed(2)} / {highThreshold.toFixed(2)}</span>
                  </div>
                </div>
              </div>

              {/* Standby Technical Footer */}
              <div className="absolute bottom-3 left-space-md right-space-md flex items-center justify-between text-outline font-label-sm text-label-sm pointer-events-none">
                <span>{selectedCamera.spec}</span>
                <span>RESOLUTION: {selectedCamera.resolution}</span>
                <span>LATENCY: {selectedCamera.latency}</span>
              </div>
            </div>
          )}

          {/* STATE B: CALIBRATION / CONNECTING SEQUENCE VIEW */}
          {systemState === 'CALIBRATING' && (
            <div className="absolute inset-0 bg-surface-container-lowest/95 backdrop-blur-md flex flex-col items-center justify-center z-30 transition-opacity duration-200">
              <div className="flex flex-col items-center text-center max-w-md p-6">
                <div className="relative w-16 h-16 mb-4 flex items-center justify-center">
                  <span className="material-symbols-outlined text-primary text-[42px] animate-spin">refresh</span>
                  <span className="material-symbols-outlined text-primary text-[18px] absolute">sensors</span>
                </div>
                <div className="inline-flex items-center gap-2 px-2.5 py-1 rounded bg-surface-container border border-primary/30 text-primary font-label-sm text-label-sm mb-2">
                  <span className="w-1.5 h-1.5 rounded-full bg-primary animate-ping"></span>
                  <span>SYSTEM CALIBRATION IN PROGRESS</span>
                </div>
                <h4 className="font-headline-sm text-on-surface font-semibold tracking-wide mb-1 font-label-lg">
                  {calibStep}
                </h4>
                <p className="font-label-sm text-on-surface-variant mb-4">
                  Configuring real-time telemetry pipeline for {selectedCamera.name}
                </p>
                {/* Progress bar */}
                <div className="w-64 h-1.5 bg-surface-container-highest rounded-full overflow-hidden border border-outline-variant/30">
                  <div
                    className="bg-primary h-full transition-all duration-300"
                    style={{ width: `${calibProgress}%` }}
                  ></div>
                </div>
              </div>
            </div>
          )}

          {/* STATE C: LIVE ACTIVE RUNWAY FEED VIEW */}
          {systemState === 'LIVE' && (
            <div className="relative w-full h-[440px] flex flex-col justify-between overflow-hidden select-none bg-[#0a0d0d]">
              {/* Visual Runway Background Simulation */}
              <div className="absolute inset-0 pointer-events-none overflow-hidden">
                {/* Sky & Horizon Gradient */}
                <div className="w-full h-[42%] bg-gradient-to-b from-[#091319] via-[#101b1e] to-[#142323]"></div>
                {/* Distant mountain silhouette */}
                <div className="absolute top-[34%] left-0 right-0 h-8 opacity-25">
                  <svg className="w-full h-full" preserveAspectRatio="none" viewBox="0 0 1000 100">
                    <path d="M0,100 L120,40 L280,75 L450,20 L610,65 L780,30 L910,70 L1000,45 L1000,100 Z" fill="#2c3a37"></path>
                  </svg>
                </div>
                {/* Perspective Ground & Tarmac Runway */}
                <div className="relative w-full h-[58%] bg-[#121616]">
                  <svg className="w-full h-full" preserveAspectRatio="none" viewBox="0 0 1000 600">
                    <polygon fill="#131a19" points="0,0 1000,0 1000,600 0,600"></polygon>
                    <polygon fill="#1a1e20" points="410,0 590,0 820,600 180,600" stroke="#252c2c" strokeWidth="2"></polygon>
                    {/* Runway Centerline Dashes */}
                    <line stroke="#ffffff" strokeOpacity="0.8" strokeWidth="4" x1="500" x2="500" y1="20" y2="70"></line>
                    <line stroke="#ffffff" strokeOpacity="0.8" strokeWidth="6" x1="500" x2="500" y1="120" y2="200"></line>
                    <line stroke="#ffffff" strokeOpacity="0.85" strokeWidth="9" x1="500" x2="500" y1="260" y2="380"></line>
                    <line stroke="#ffffff" strokeOpacity="0.9" strokeWidth="12" x1="500" x2="500" y1="440" y2="600"></line>
                    {/* Runway Threshold Markings (18L) */}
                    <line stroke="#ffffff" strokeOpacity="0.7" strokeWidth="3" x1="430" x2="445" y1="35" y2="35"></line>
                    <line stroke="#ffffff" strokeOpacity="0.7" strokeWidth="3" x1="455" x2="470" y1="35" y2="35"></line>
                    <line stroke="#ffffff" strokeOpacity="0.7" strokeWidth="3" x1="530" x2="545" y1="35" y2="35"></line>
                    <line stroke="#ffffff" strokeOpacity="0.7" strokeWidth="3" x1="555" x2="570" y1="35" y2="35"></line>
                    {/* Runway Edge Lights */}
                    <circle cx="395" cy="50" fill="#ffddb8" r="2"></circle>
                    <circle cx="605" cy="50" fill="#ffddb8" r="2"></circle>
                    <circle cx="340" cy="180" fill="#ffddb8" r="3"></circle>
                    <circle cx="660" cy="180" fill="#ffddb8" r="3"></circle>
                    <circle cx="270" cy="350" fill="#ffddb8" r="4"></circle>
                    <circle cx="730" cy="350" fill="#ffddb8" r="4"></circle>
                    <circle cx="190" cy="570" fill="#4edea3" r="5"></circle>
                    <circle cx="810" cy="570" fill="#4edea3" r="5"></circle>
                    {/* RED RUNWAY EXCLUSION ZONE POLYGON */}
                    <polygon className="zone-pulse-poly" fill="rgba(255, 116, 116, 0.08)" points="360,60 640,60 760,540 240,540" stroke="#ff7a73" strokeDasharray="8 4" strokeWidth="1.8"></polygon>
                    <text fill="#ffb4ab" fontFamily="'JetBrains Mono', monospace" fontSize="16" fontWeight="600" letterSpacing="3" opacity="0.65" textAnchor="middle" x="500" y="320">
                      CRITICAL RUNWAY EXCLUSION ZONE (REZ)
                    </text>
                  </svg>
                </div>
                <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,transparent_0%,rgba(0,0,0,0.6)_100%)]"></div>
              </div>

              {/* TOP HUD TELEMETRY OVERLAY BAR */}
              <div className="relative z-20 p-3 bg-surface-container-lowest/85 backdrop-blur border-b border-outline-variant/30 flex items-center justify-between">
                <div className="flex items-center gap-space-md">
                  <div className="flex items-center gap-2 px-2 py-0.5 rounded-DEFAULT bg-primary/10 border border-primary/40 text-primary font-label-sm text-label-sm font-semibold">
                    <span className="w-2 h-2 rounded-full bg-primary animate-ping"></span>
                    STREAM ACTIVE
                  </div>
                  <div className="flex items-center gap-1.5 font-label-sm text-label-sm text-on-surface">
                    <span className="text-outline">TARGET:</span>
                    <span className="font-medium">{selectedCamera.tag}</span>
                  </div>
                  <div className="hidden sm:flex items-center gap-1.5 font-label-sm text-label-sm text-on-surface-variant">
                    <span className="text-outline">FPS:</span>
                    <span className="font-medium text-primary">30.0</span>
                    <span className="text-outline-variant">|</span>
                    <span className="text-outline">LATENCY:</span>
                    <span className="font-medium text-primary">{selectedCamera.latency}</span>
                  </div>
                </div>
                <div className="flex items-center gap-space-md">
                  <div className="flex items-center gap-2 font-label-sm text-label-sm text-on-surface">
                    <span className="material-symbols-outlined text-[15px] text-primary">timer</span>
                    <span className="font-mono text-primary font-medium">{feedTimerText}</span>
                  </div>
                  <button
                    onClick={stopToStandby}
                    className="h-7 px-3 bg-surface-container-high border border-outline-variant text-on-surface hover:bg-error-container hover:text-error hover:border-error text-label-sm font-label-sm rounded-DEFAULT flex items-center gap-1.5 transition-colors cursor-pointer"
                    title="Stop live detection and return to idle standby"
                    type="button"
                  >
                    <span className="material-symbols-outlined text-[15px] text-error">stop</span>
                    <span>Stop / Return to Idle</span>
                  </button>
                </div>
              </div>

              {/* DETECTED BIRD BOUNDING BOXES OVERLAY */}
              <div className="relative z-10 w-full flex-1 pointer-events-none">
                {/* Bounding Box #B-104 (Inside Exclusion Zone - High Alert) */}
                <div
                  className="absolute left-[38%] top-[28%] w-32 h-24 border-2 border-error bg-error/10 transition-all duration-700 pointer-events-auto"
                  style={{ transform: `translate(${jitter1.x}px, ${jitter1.y}px)` }}
                >
                  <div className="absolute -top-1 -left-1 w-2 h-2 bg-error"></div>
                  <div className="absolute -top-1 -right-1 w-2 h-2 bg-error"></div>
                  <div className="absolute -bottom-1 -left-1 w-2 h-2 bg-error"></div>
                  <div className="absolute -bottom-1 -right-1 w-2 h-2 bg-error"></div>
                  <div className="absolute -top-6 left-0 bg-error text-surface font-label-sm text-[10px] font-bold px-1.5 py-0.5 flex items-center gap-1 shadow whitespace-nowrap">
                    <span>#B-104</span>
                    <span className="bg-surface/30 px-1 rounded">48 km/h</span>
                    <span className="text-[9px] uppercase font-bold tracking-tight">CRITICAL REZ</span>
                  </div>
                  <div className="absolute inset-0 flex items-center justify-center opacity-70">
                    <div className="w-3 h-3 border border-error rounded-full flex items-center justify-center">
                      <div className="w-1 h-1 bg-error rounded-full"></div>
                    </div>
                  </div>
                  <div className="absolute bottom-0.5 right-1 font-label-sm text-[9px] text-error font-mono font-bold">d:38m</div>
                </div>

                {/* Bounding Box #B-108 (Perimeter Runway - Medium Risk) */}
                <div
                  className="absolute left-[62%] top-[45%] w-28 h-20 border border-secondary bg-secondary/10 transition-all duration-700 pointer-events-auto"
                  style={{ transform: `translate(${jitter2.x}px, ${jitter2.y}px)` }}
                >
                  <div className="absolute -top-1 -left-1 w-1.5 h-1.5 bg-secondary"></div>
                  <div className="absolute -top-1 -right-1 w-1.5 h-1.5 bg-secondary"></div>
                  <div className="absolute -bottom-1 -left-1 w-1.5 h-1.5 bg-secondary"></div>
                  <div className="absolute -bottom-1 -right-1 w-1.5 h-1.5 bg-secondary"></div>
                  <div className="absolute -top-5 left-0 bg-secondary text-surface font-label-sm text-[10px] font-bold px-1.5 py-0.5 flex items-center gap-1 shadow whitespace-nowrap">
                    <span>#B-108</span>
                    <span className="bg-surface/30 px-1 rounded">39 km/h</span>
                    <span>WARN</span>
                  </div>
                  <div className="absolute inset-0 flex items-center justify-center opacity-60">
                    <div className="w-2.5 h-2.5 border border-secondary rounded-full"></div>
                  </div>
                  <div className="absolute bottom-0.5 right-1 font-label-sm text-[9px] text-secondary font-mono font-bold">d:84m</div>
                </div>

                {/* Bounding Box #B-112 (Glidepath Verge - Low Risk) */}
                <div
                  className="absolute left-[18%] top-[52%] w-24 h-16 border border-primary bg-primary/10 transition-all duration-700 pointer-events-auto"
                  style={{ transform: `translate(${jitter3.x}px, ${jitter3.y}px)` }}
                >
                  <div className="absolute -top-5 left-0 bg-surface-container-high border border-primary text-primary font-label-sm text-[10px] font-medium px-1.5 py-0.5 flex items-center gap-1 whitespace-nowrap">
                    <span>#B-112</span>
                    <span>24 km/h</span>
                    <span className="text-primary font-bold">LOW</span>
                  </div>
                  <div className="absolute inset-0 flex items-center justify-center opacity-40">
                    <div className="w-2 h-2 border border-primary rounded-full"></div>
                  </div>
                  <div className="absolute bottom-0.5 right-1 font-label-sm text-[9px] text-primary font-mono">d:142m</div>
                </div>
              </div>

              {/* BOTTOM HUD FOOTER BAR */}
              <div className="relative z-20 px-3 py-1.5 bg-surface-container-lowest/90 backdrop-blur border-t border-outline-variant/30 flex items-center justify-between text-outline font-label-sm text-label-sm">
                <div className="flex items-center gap-3">
                  <span className="text-on-surface flex items-center gap-1">
                    <span className="material-symbols-outlined text-[14px] text-primary">visibility</span>
                    <span>3 DETECTIONS ACTIVE</span>
                  </span>
                  <span>•</span>
                  <span className="text-error font-medium">PEAK RISK: 0.81 (HIGH)</span>
                  <span>•</span>
                  <span className="text-on-surface-variant">INFERENCE: 14.8ms / FRAME</span>
                </div>
                <div className="flex items-center gap-3">
                  <span className="text-on-surface-variant font-mono">YOLOv8x + DeepSORT v2.1</span>
                  <span>•</span>
                  <span className="text-primary">AUTO-TRACK ENGAGED</span>
                </div>
              </div>
            </div>
          )}
        </div>
      </section>

      {/* Section 3: Previous Episodes Alert History (Log Dataframe) */}
      <section className="flex flex-col gap-space-sm mb-space-xl">
        <div className="flex items-center justify-between mb-space-xs">
          <div className="flex items-center gap-space-sm">
            <span className="material-symbols-outlined text-outline text-[18px]">history</span>
            <h3 className="font-headline-sm text-headline-sm text-on-surface font-semibold tracking-tight">Recent Surveillance Episodes</h3>
            <span className="px-2 py-0.5 bg-surface-container border border-outline-variant/30 text-on-surface-variant font-label-sm text-label-sm rounded-DEFAULT">Archive Session #84</span>
          </div>
          <Link
            to="/alerts"
            className="font-label-sm text-label-sm text-primary hover:text-primary-fixed-dim transition-colors flex items-center gap-1"
          >
            <span>View Full Alert History</span>
            <span className="material-symbols-outlined text-[14px]">arrow_forward</span>
          </Link>
        </div>

        {/* Analytical Data Table */}
        <div className="w-full bg-surface-container-low border border-outline-variant/30 rounded-DEFAULT overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full border-collapse text-left">
              <thead>
                <tr className="bg-surface-container border-b border-outline-variant/30">
                  <th className="py-space-sm px-space-md font-label-sm text-label-sm text-outline uppercase tracking-wider font-semibold">Episode ID</th>
                  <th className="py-space-sm px-space-md font-label-sm text-label-sm text-outline uppercase tracking-wider font-semibold">Start Time (UTC)</th>
                  <th className="py-space-sm px-space-md font-label-sm text-label-sm text-outline uppercase tracking-wider font-semibold">End Time (UTC)</th>
                  <th className="py-space-sm px-space-md font-label-sm text-label-sm text-outline uppercase tracking-wider font-semibold">Duration</th>
                  <th className="py-space-sm px-space-md font-label-sm text-label-sm text-outline uppercase tracking-wider font-semibold">Peak Risk Level</th>
                  <th className="py-space-sm px-space-md font-label-sm text-label-sm text-outline uppercase tracking-wider font-semibold text-right">Peak Score</th>
                  <th className="py-space-sm px-space-md font-label-sm text-label-sm text-outline uppercase tracking-wider font-semibold">Primary Driver</th>
                  <th className="py-space-sm px-space-md font-label-sm text-label-sm text-outline uppercase tracking-wider font-semibold text-right">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-outline-variant/20 font-body-sm text-body-sm">
                {recentEpisodes.map((ep) => {
                  let badge = (
                    <span className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded-DEFAULT bg-on-primary-container/40 border border-primary/50 text-primary font-label-sm text-label-sm font-medium">
                      <span className="material-symbols-outlined text-[13px]">check_circle</span>
                      LOW
                    </span>
                  );
                  let scoreColor = 'text-primary';

                  if (ep.riskLevel === 'HIGH') {
                    badge = (
                      <span className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded-DEFAULT bg-error-container/40 border border-error/50 text-error font-label-sm text-label-sm font-medium">
                        <span className="material-symbols-outlined text-[13px]">warning</span>
                        HIGH
                      </span>
                    );
                    scoreColor = 'text-error';
                  } else if (ep.riskLevel === 'MEDIUM') {
                    badge = (
                      <span className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded-DEFAULT bg-on-secondary-container/40 border border-secondary/50 text-secondary font-label-sm text-label-sm font-medium">
                        <span className="material-symbols-outlined text-[13px]">report_problem</span>
                        MEDIUM
                      </span>
                    );
                    scoreColor = 'text-secondary';
                  }

                  return (
                    <tr key={ep.id} className="hover:bg-surface-container/60 transition-colors">
                      <td className="py-2.5 px-space-md font-label-md text-label-md text-on-surface font-semibold">{ep.id}</td>
                      <td className="py-2.5 px-space-md font-label-sm text-label-sm text-on-surface-variant">{ep.startTime}</td>
                      <td className="py-2.5 px-space-md font-label-sm text-label-sm text-on-surface-variant">{ep.endTime}</td>
                      <td className="py-2.5 px-space-md font-label-sm text-label-sm text-on-surface-variant">{ep.duration}</td>
                      <td className="py-2.5 px-space-md">{badge}</td>
                      <td className={`py-2.5 px-space-md font-label-md text-label-md ${scoreColor} text-right font-semibold`}>
                        {ep.peakScore.toFixed(2)}
                      </td>
                      <td className="py-2.5 px-space-md text-on-surface">{ep.mainDriver}</td>
                      <td className="py-2.5 px-space-md text-right">
                        <button
                          onClick={() => handleInspectEpisode(ep.id)}
                          className="text-outline hover:text-on-surface transition-colors cursor-pointer"
                          title="Inspect Episode Telemetry"
                          type="button"
                        >
                          <span className="material-symbols-outlined text-[18px]">readiness_score</span>
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
          {/* Table Summary Footer */}
          <div className="px-space-md py-2 bg-surface-container/50 border-t border-outline-variant/30 flex items-center justify-between text-outline font-label-sm text-label-sm">
            <span>Showing last 4 monitoring sessions of 84 recorded</span>
            <div className="flex items-center gap-space-md">
              <span>High Strike Incidents: 2</span>
              <span>False Positives Filtered: 99.4%</span>
            </div>
          </div>
        </div>
      </section>

      {/* Technical Diagnostics / Sensor Health Bar */}
      <section className="grid grid-cols-2 md:grid-cols-4 gap-space-sm pt-space-xs border-t border-outline-variant/20">
        <div className="p-space-sm bg-surface-container-low border border-outline-variant/20 rounded-DEFAULT flex items-center justify-between">
          <span className="font-label-sm text-label-sm text-outline">OPTICAL FEED</span>
          <span className="font-label-sm text-label-sm text-primary font-medium">1080p 60Hz NOMINAL</span>
        </div>
        <div className="p-space-sm bg-surface-container-low border border-outline-variant/20 rounded-DEFAULT flex items-center justify-between">
          <span className="font-label-sm text-label-sm text-outline">CUDA ACCELERATION</span>
          <span className="font-label-sm text-label-sm text-primary font-medium">NVIDIA RTX ENABLED</span>
        </div>
        <div className="p-space-sm bg-surface-container-low border border-outline-variant/20 rounded-DEFAULT flex items-center justify-between">
          <span className="font-label-sm text-label-sm text-outline">ATC DATALINK</span>
          <span className="font-label-sm text-label-sm text-on-surface-variant font-medium">CONNECTED (KDEN-TWR)</span>
        </div>
        <div className="p-space-sm bg-surface-container-low border border-outline-variant/20 rounded-DEFAULT flex items-center justify-between">
          <span className="font-label-sm text-label-sm text-outline">INFERENCE ENGINE</span>
          <span className="font-label-sm text-label-sm text-on-surface-variant font-medium">YOLOv8x-AVIAN-v1.4</span>
        </div>
      </section>
    </div>
  );
}

