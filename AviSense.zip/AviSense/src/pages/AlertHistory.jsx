import React, { useState, useMemo } from 'react';
import { useApp } from '../context/AppContext';
import { EPISODES } from '../data/mockData';
import './AlertHistory.css';

export default function AlertHistory() {
  const { selectedCamera, selectedEpisodeId, setSelectedEpisodeId } = useApp();

  const [riskFilter, setRiskFilter] = useState('ALL'); // 'ALL' | 'HIGH' | 'MEDIUM' | 'LOW'
  const [searchQuery, setSearchQuery] = useState('');
  const [sortBy, setSortBy] = useState('peak'); // 'peak' | 'recent' | 'duration'

  // Filter and sort episodes
  const filteredEpisodes = useMemo(() => {
    return EPISODES.filter((ep) => {
      // Risk level filter
      if (riskFilter !== 'ALL' && ep.riskLevel !== riskFilter) {
        return false;
      }
      // Search query
      if (searchQuery.trim()) {
        const query = searchQuery.toLowerCase();
        const matchesId = ep.id.toLowerCase().includes(query);
        const matchesDriver = ep.mainDriver.toLowerCase().includes(query);
        const matchesSummary = ep.summary.toLowerCase().includes(query);
        if (!matchesId && !matchesDriver && !matchesSummary) return false;
      }
      return true;
    }).sort((a, b) => {
      if (sortBy === 'peak') {
        return b.peakScore - a.peakScore;
      } else if (sortBy === 'recent') {
        return b.startTime.localeCompare(a.startTime);
      } else if (sortBy === 'duration') {
        return b.duration.localeCompare(a.duration);
      }
      return 0;
    });
  }, [riskFilter, searchQuery, sortBy]);

  // Selected episode object
  const activeEpisode = useMemo(() => {
    return (
      EPISODES.find((e) => e.id === selectedEpisodeId) ||
      filteredEpisodes[0] ||
      EPISODES[0]
    );
  }, [selectedEpisodeId, filteredEpisodes]);

  return (
    <div className="flex flex-col w-full gap-space-lg pb-space-xl alert-history-container">
      {/* PAGE HEADER: Clean, minimal & direct */}
      <div className="flex flex-col gap-space-md border-b border-[#242828] pb-space-md">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-space-sm">
          <div>
            <h2 className="font-headline-lg text-headline-lg text-[#ffffff] tracking-tight font-semibold">
              Alert History
            </h2>
            <p className="font-body-sm text-body-sm text-[#9ca3af] mt-0.5">
              Archive of bird-strike threat episodes and risk detections
            </p>
          </div>
          <div className="flex items-center gap-2 font-label-sm text-label-sm text-[#9ca3af] px-3 py-1.5 bg-[#111313] border border-[#242828] rounded-DEFAULT">
            <span className="w-2 h-2 rounded-full bg-[#10b981]"></span>
            <span>{selectedCamera.name.toUpperCase()} ARCHIVE</span>
            <span className="text-[#242828]">|</span>
            <span>SECTOR DUSK CYCLE</span>
          </div>
        </div>

        {/* FILTERING & SORTING BAR */}
        <div className="bg-[#111313] border border-[#242828] p-2 rounded-DEFAULT flex flex-wrap items-center justify-between gap-3">
          {/* Level filter buttons (Streamlit st.pills style) */}
          <div className="flex items-center gap-1 bg-[#000000] p-1 rounded-DEFAULT border border-[#242828]" id="risk-filter-group">
            <button
              onClick={() => setRiskFilter('ALL')}
              className={`px-3 py-1 rounded-DEFAULT font-label-sm text-label-sm font-medium transition-colors cursor-pointer ${
                riskFilter === 'ALL'
                  ? 'text-[#ffffff] bg-[#161818] border border-[#242828]'
                  : 'text-[#9ca3af] hover:text-[#ffffff] hover:bg-[#161818]'
              }`}
              type="button"
            >
              All
            </button>
            <button
              onClick={() => setRiskFilter('HIGH')}
              className={`px-3 py-1 rounded-DEFAULT font-label-sm text-label-sm font-medium transition-colors cursor-pointer ${
                riskFilter === 'HIGH'
                  ? 'text-[#ef4444] bg-[#161818] border border-[#242828]'
                  : 'text-[#9ca3af] hover:text-[#ef4444] hover:bg-[#161818]'
              }`}
              type="button"
            >
              High Risk
            </button>
            <button
              onClick={() => setRiskFilter('MEDIUM')}
              className={`px-3 py-1 rounded-DEFAULT font-label-sm text-label-sm font-medium transition-colors cursor-pointer ${
                riskFilter === 'MEDIUM'
                  ? 'text-[#f59e0b] bg-[#161818] border border-[#242828]'
                  : 'text-[#9ca3af] hover:text-[#f59e0b] hover:bg-[#161818]'
              }`}
              type="button"
            >
              Medium Risk
            </button>
            <button
              onClick={() => setRiskFilter('LOW')}
              className={`px-3 py-1 rounded-DEFAULT font-label-sm text-label-sm font-medium transition-colors cursor-pointer ${
                riskFilter === 'LOW'
                  ? 'text-[#10b981] bg-[#161818] border border-[#242828]'
                  : 'text-[#9ca3af] hover:text-[#10b981] hover:bg-[#161818]'
              }`}
              type="button"
            >
              Low / Nominal
            </button>
          </div>

          {/* Search & Sort dropdown controls */}
          <div className="flex items-center gap-2 flex-1 min-w-[280px] justify-end">
            <div className="relative flex-1 max-w-xs">
              <span className="material-symbols-outlined absolute left-2.5 top-2 text-[16px] text-[#9ca3af]">
                search
              </span>
              <input
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full h-8 pl-8 pr-2 bg-[#000000] border border-[#242828] text-[#ffffff] font-body-sm text-body-sm rounded-DEFAULT focus:outline-none focus:border-[#10b981] placeholder-[#9ca3af]/50 transition-colors"
                placeholder="Search episode or driver..."
                type="text"
              />
            </div>
            <div className="relative">
              <select
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value)}
                className="h-8 pl-2.5 pr-8 bg-[#000000] border border-[#242828] rounded-DEFAULT font-label-sm text-label-sm text-[#ffffff] appearance-none cursor-pointer focus:outline-none focus:border-[#10b981]"
              >
                <option value="peak">Sort by Peak Score (High to Low)</option>
                <option value="recent">Sort by Most Recent</option>
                <option value="duration">Sort by Duration</option>
              </select>
              <span className="material-symbols-outlined absolute right-2 top-2 text-[14px] text-[#9ca3af] pointer-events-none">
                expand_more
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* MAIN SPLIT WORKSPACE: 60% TABLE / 40% DETAIL INSPECTION */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-space-lg items-start">
        {/* LEFT COLUMN: ALERT EPISODES TABLE (~60%) */}
        <div className="lg:col-span-7 flex flex-col bg-[#111313] rounded-DEFAULT overflow-hidden border border-[#242828]">
          {/* Table Title Bar */}
          <div className="px-4 py-3 bg-[#161818] border-b border-[#242828] flex items-center justify-between">
            <div className="flex items-center gap-2">
              <span className="material-symbols-outlined text-[16px] text-[#10b981]">table_rows</span>
              <span className="font-label-sm text-label-sm uppercase tracking-wider text-[#ffffff] font-semibold">
                Surveillance Episodes
              </span>
            </div>
            <span className="font-label-sm text-label-sm text-[#9ca3af]">Sector {selectedCamera.code} Log</span>
          </div>

          {/* Table Component */}
          <div className="overflow-x-auto w-full">
            <table className="w-full text-left border-collapse font-body-sm">
              <thead>
                <tr className="bg-[#000000] text-[#9ca3af] font-label-sm text-label-sm uppercase border-b border-[#242828]">
                  <th className="py-2.5 pl-4 pr-2 font-medium tracking-wider">Episode ID</th>
                  <th className="py-2.5 px-2 font-medium tracking-wider">Start (UTC)</th>
                  <th className="py-2.5 px-2 font-medium tracking-wider">End (UTC)</th>
                  <th className="py-2.5 px-2 font-medium tracking-wider">Duration</th>
                  <th className="py-2.5 px-2 font-medium tracking-wider">Risk Level</th>
                  <th className="py-2.5 px-2 font-medium tracking-wider text-right">Peak Score</th>
                  <th className="py-2.5 pl-2 pr-4 font-medium tracking-wider">Main Driver</th>
                </tr>
              </thead>
              <tbody className="font-label-sm text-label-sm divide-y divide-[#242828]/50" id="episodes-tbody">
                {filteredEpisodes.length === 0 ? (
                  <tr>
                    <td colSpan="7" className="py-8 text-center text-[#9ca3af]">
                      No surveillance episodes found matching the filter criteria.
                    </td>
                  </tr>
                ) : (
                  filteredEpisodes.map((ep) => {
                    const isSelected = ep.id === activeEpisode.id;
                    let borderClass = '';
                    let badgeClass = '';
                    let badgeIcon = 'check_circle';
                    let scoreClass = 'text-[#10b981]';

                    if (ep.riskLevel === 'HIGH') {
                      borderClass = 'border-l-2 border-[#ef4444]';
                      badgeClass = 'bg-[#ef4444]/15 border border-[#ef4444]/30 text-[#ef4444]';
                      badgeIcon = 'warning';
                      scoreClass = 'text-[#ef4444]';
                    } else if (ep.riskLevel === 'MEDIUM') {
                      borderClass = 'border-l-2 border-[#f59e0b]';
                      badgeClass = 'bg-[#f59e0b]/15 border border-[#f59e0b]/30 text-[#f59e0b]';
                      badgeIcon = 'report_problem';
                      scoreClass = 'text-[#f59e0b]';
                    } else {
                      borderClass = 'border-l-2 border-[#10b981]';
                      badgeClass = 'bg-[#10b981]/15 border border-[#10b981]/30 text-[#10b981]';
                      badgeIcon = 'check_circle';
                      scoreClass = 'text-[#10b981]';
                    }

                    return (
                      <tr
                        key={ep.id}
                        onClick={() => setSelectedEpisodeId(ep.id)}
                        className={`cursor-pointer transition-colors ${
                          isSelected
                            ? `bg-[#161818] ${borderClass} text-[#ffffff]`
                            : 'hover:bg-[#161818] text-[#9ca3af]'
                        }`}
                      >
                        <td className="py-2.5 pl-4 pr-2 font-semibold text-[#ffffff] font-mono">{ep.id}</td>
                        <td className="py-2.5 px-2 text-[#9ca3af] font-mono">{ep.startTime}</td>
                        <td className="py-2.5 px-2 text-[#9ca3af] font-mono">{ep.endTime}</td>
                        <td className="py-2.5 px-2 text-[#ffffff]">{ep.duration}</td>
                        <td className="py-2.5 px-2">
                          <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-DEFAULT font-medium text-[11px] ${badgeClass}`}>
                            <span className="material-symbols-outlined text-[13px]">{badgeIcon}</span>
                            {ep.riskLevel === 'HIGH' ? 'High' : ep.riskLevel === 'MEDIUM' ? 'Medium' : 'Low'}
                          </span>
                        </td>
                        <td className={`py-2.5 px-2 text-right font-mono font-semibold ${scoreClass}`}>
                          {ep.peakScore.toFixed(2)}
                        </td>
                        <td className="py-2.5 pl-2 pr-4 truncate max-w-[130px]" title={ep.mainDriver}>
                          {ep.driverName || ep.mainDriver}
                        </td>
                      </tr>
                    );
                  })
                )}
              </tbody>
            </table>
          </div>

          {/* Clean Pagination / Record counter */}
          <div className="px-4 py-2.5 bg-[#161818] border-t border-[#242828] flex items-center justify-between font-label-sm text-label-sm text-[#9ca3af]">
            <span>Showing {filteredEpisodes.length} episodes · Total 84 recorded</span>
            <div className="flex items-center gap-2">
              <button
                className="px-2.5 py-1 rounded-DEFAULT bg-[#000000] border border-[#242828] text-[#9ca3af] opacity-50 cursor-not-allowed font-label-sm text-label-sm"
                type="button"
                disabled
              >
                Previous
              </button>
              <span className="px-2 font-mono text-[#ffffff]">1 / 11</span>
              <button
                className="px-2.5 py-1 rounded-DEFAULT bg-[#000000] border border-[#242828] text-[#ffffff] hover:bg-[#242828] transition-colors font-label-sm text-label-sm cursor-pointer"
                type="button"
              >
                Next
              </button>
            </div>
          </div>
        </div>

        {/* RIGHT COLUMN: SELECTED EPISODE DETAILS PANEL (~40%) */}
        {activeEpisode && (
          <div className="lg:col-span-5 flex flex-col bg-[#111313] rounded-DEFAULT border border-[#242828] overflow-hidden">
            {/* Header */}
            <div className="px-4 py-3 bg-[#161818] border-b border-[#242828] flex items-center justify-between">
              <div>
                <span className="font-label-sm text-label-sm text-[#9ca3af] uppercase tracking-wider block">
                  Episode Details
                </span>
                <span className="font-headline-sm text-[16px] font-semibold text-[#ffffff] font-mono">
                  {activeEpisode.id}
                </span>
              </div>
              <div
                className={`flex items-center gap-1.5 px-2.5 py-1 rounded-DEFAULT font-label-sm text-label-sm font-semibold ${
                  activeEpisode.riskLevel === 'HIGH'
                    ? 'bg-[#ef4444]/15 border border-[#ef4444]/30 text-[#ef4444]'
                    : activeEpisode.riskLevel === 'MEDIUM'
                    ? 'bg-[#f59e0b]/15 border border-[#f59e0b]/30 text-[#f59e0b]'
                    : 'bg-[#10b981]/15 border border-[#10b981]/30 text-[#10b981]'
                }`}
              >
                <span className="material-symbols-outlined text-[14px]">
                  {activeEpisode.riskLevel === 'HIGH' ? 'warning' : activeEpisode.riskLevel === 'MEDIUM' ? 'report_problem' : 'check_circle'}
                </span>
                <span>
                  {activeEpisode.riskLevel} {activeEpisode.peakScore.toFixed(2)}
                </span>
              </div>
            </div>

            <div className="p-space-md flex flex-col gap-space-md">
              {/* Key Historical Summary */}
              <div className="flex flex-col gap-2 bg-[#000000] p-3 rounded-DEFAULT border border-[#242828]">
                <span className="font-label-sm text-label-sm text-[#9ca3af] uppercase tracking-wider">
                  Historical Summary
                </span>
                <div className="grid grid-cols-2 gap-y-2 gap-x-4 font-label-sm text-label-sm pt-1">
                  <div className="flex flex-col">
                    <span className="text-[#9ca3af]">Start Time</span>
                    <span className="text-[#ffffff] font-mono font-medium">{activeEpisode.startTime} UTC</span>
                  </div>
                  <div className="flex flex-col">
                    <span className="text-[#9ca3af]">End Time</span>
                    <span className="text-[#ffffff] font-mono font-medium">{activeEpisode.endTime} UTC</span>
                  </div>
                  <div className="flex flex-col">
                    <span className="text-[#9ca3af]">Total Duration</span>
                    <span className="text-[#ffffff] font-medium">{activeEpisode.duration}</span>
                  </div>
                  <div className="flex flex-col">
                    <span className="text-[#9ca3af]">Peak Risk Score</span>
                    <span
                      className={`font-mono font-semibold ${
                        activeEpisode.riskLevel === 'HIGH'
                          ? 'text-[#ef4444]'
                          : activeEpisode.riskLevel === 'MEDIUM'
                          ? 'text-[#f59e0b]'
                          : 'text-[#10b981]'
                      }`}
                    >
                      {activeEpisode.peakScore.toFixed(2)} ({activeEpisode.riskLevel} Risk)
                    </span>
                  </div>
                </div>
                <div className="border-t border-[#242828] pt-2 mt-1 flex flex-col">
                  <span className="font-label-sm text-label-sm text-[#9ca3af]">Main Risk Driver</span>
                  <span className="text-[#ffffff] font-medium text-[13px] mt-0.5">
                    {activeEpisode.mainDriver}
                  </span>
                </div>
              </div>

              {/* Birds Involved during Episode */}
              <div className="flex flex-col gap-2 bg-[#000000] p-3 rounded-DEFAULT border border-[#242828]">
                <div className="flex items-center justify-between">
                  <span className="font-label-sm text-label-sm text-[#9ca3af] uppercase tracking-wider">
                    Birds Involved
                  </span>
                  <span className="font-label-sm text-label-sm text-[#ffffff] font-mono font-medium">
                    {activeEpisode.birdsTracked} birds tracked
                  </span>
                </div>
                <div className="grid grid-cols-2 gap-3 pt-1">
                  <div className="p-2 bg-[#161818] border border-[#242828] rounded-DEFAULT">
                    <span className="text-[#9ca3af] font-label-sm text-[11px] block">Identified Targets</span>
                    <span className="text-[#ffffff] font-mono font-medium text-[12px] mt-0.5 block truncate">
                      {activeEpisode.identifiedTargets}
                    </span>
                  </div>
                  <div className="p-2 bg-[#161818] border border-[#242828] rounded-DEFAULT">
                    <span className="text-[#9ca3af] font-label-sm text-[11px] block">Maximum Speed</span>
                    <span className="text-[#ffffff] font-mono font-medium text-[12px] mt-0.5 block">
                      {activeEpisode.maxSpeed}
                    </span>
                  </div>
                </div>
              </div>

              {/* Factor Contributions at Peak */}
              <div className="flex flex-col gap-2 bg-[#000000] p-3 rounded-DEFAULT border border-[#242828]">
                <div className="flex items-center justify-between">
                  <span className="font-label-sm text-label-sm text-[#9ca3af] uppercase tracking-wider">
                    Factor Contributions at Peak
                  </span>
                  <span className="font-label-sm text-[11px] text-[#ef4444] font-medium">
                    Primary: {activeEpisode.driverName}
                  </span>
                </div>
                <div className="flex flex-col gap-2.5 font-label-sm text-[12px] pt-1">
                  {/* Runway Proximity */}
                  <div className="flex flex-col gap-1">
                    <div className="flex justify-between items-center">
                      <span className="text-[#ffffff] font-medium">
                        Runway Proximity {activeEpisode.factors.proximity.isPrimary && (
                          <span className="text-[10px] text-[#ef4444] font-normal">(Primary Driver)</span>
                        )}
                      </span>
                      <span className="text-[#ef4444] font-mono font-semibold">
                        {activeEpisode.factors.proximity.value.toFixed(2)}
                      </span>
                    </div>
                    <div className="w-full h-1.5 bg-[#161818] rounded-full overflow-hidden">
                      <div
                        className="h-full bg-[#ef4444] rounded-full"
                        style={{ width: `${Math.round(activeEpisode.factors.proximity.value * 100)}%` }}
                      ></div>
                    </div>
                  </div>

                  {/* Bird Count */}
                  <div className="flex flex-col gap-1">
                    <div className="flex justify-between items-center">
                      <span className="text-[#9ca3af]">
                        Bird Count {activeEpisode.factors.count.isPrimary && (
                          <span className="text-[10px] text-[#f59e0b] font-normal">(Primary Driver)</span>
                        )}
                      </span>
                      <span className="text-[#ffffff] font-mono font-medium">
                        {activeEpisode.factors.count.value.toFixed(2)}
                      </span>
                    </div>
                    <div className="w-full h-1.5 bg-[#161818] rounded-full overflow-hidden">
                      <div
                        className="h-full bg-[#f59e0b] rounded-full"
                        style={{ width: `${Math.round(activeEpisode.factors.count.value * 100)}%` }}
                      ></div>
                    </div>
                  </div>

                  {/* Flock Size */}
                  <div className="flex flex-col gap-1">
                    <div className="flex justify-between items-center">
                      <span className="text-[#9ca3af]">
                        Flock Size {activeEpisode.factors.flockSize.isPrimary && (
                          <span className="text-[10px] text-[#f59e0b] font-normal">(Primary Driver)</span>
                        )}
                      </span>
                      <span className="text-[#ffffff] font-mono font-medium">
                        {activeEpisode.factors.flockSize.value.toFixed(2)}
                      </span>
                    </div>
                    <div className="w-full h-1.5 bg-[#161818] rounded-full overflow-hidden">
                      <div
                        className="h-full bg-[#f59e0b] rounded-full"
                        style={{ width: `${Math.round(activeEpisode.factors.flockSize.value * 100)}%` }}
                      ></div>
                    </div>
                  </div>

                  {/* Speed / Velocity */}
                  <div className="flex flex-col gap-1">
                    <div className="flex justify-between items-center">
                      <span className="text-[#9ca3af]">
                        Speed / Velocity {activeEpisode.factors.velocity.isPrimary && (
                          <span className="text-[10px] text-[#f59e0b] font-normal">(Primary Driver)</span>
                        )}
                      </span>
                      <span className="text-[#ffffff] font-mono font-medium">
                        {activeEpisode.factors.velocity.value.toFixed(2)}
                      </span>
                    </div>
                    <div className="w-full h-1.5 bg-[#161818] rounded-full overflow-hidden">
                      <div
                        className="h-full bg-[#f59e0b] rounded-full"
                        style={{ width: `${Math.round(activeEpisode.factors.velocity.value * 100)}%` }}
                      ></div>
                    </div>
                  </div>

                  {/* Time of Day */}
                  <div className="flex flex-col gap-1">
                    <div className="flex justify-between items-center">
                      <span className="text-[#9ca3af]">
                        Time of Day {activeEpisode.factors.timeOfDay.isPrimary && (
                          <span className="text-[10px] text-[#10b981] font-normal">(Primary Driver)</span>
                        )}
                      </span>
                      <span className="text-[#ffffff] font-mono font-medium">
                        {activeEpisode.factors.timeOfDay.value.toFixed(2)}
                      </span>
                    </div>
                    <div className="w-full h-1.5 bg-[#161818] rounded-full overflow-hidden">
                      <div
                        className="h-full bg-[#10b981] rounded-full"
                        style={{ width: `${Math.round(activeEpisode.factors.timeOfDay.value * 100)}%` }}
                      ></div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Incident Note / Summary */}
              <div className="flex flex-col gap-1.5 bg-[#161818] p-3 rounded-DEFAULT border border-[#242828]">
                <div className="flex items-center gap-1.5 text-[#9ca3af] font-label-sm text-[11px] uppercase tracking-wider">
                  <span className="material-symbols-outlined text-[14px] text-[#10b981]">description</span>
                  <span>Incident Summary</span>
                </div>
                <p className="font-body-sm text-[12px] text-[#ffffff] leading-relaxed">
                  {activeEpisode.summary}
                </p>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

