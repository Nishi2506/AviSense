import React from 'react';
import { useApp } from '../context/AppContext';
import './LiveMonitoring.css';

export default function LiveMonitoring() {
  const { selectedCamera, medThreshold, highThreshold } = useApp();

  return (
    <div className="flex flex-col w-full live-monitoring-container">
      <div className="flex flex-col gap-space-lg w-full max-w-[1720px] mx-auto pb-space-xl">
        {/* 1. Top Alert Banner / Key Data Row */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-space-md">
          {/* Card 1: Risk Level & Score */}
          <div className="bg-surface-container-low border border-outline-variant/30 rounded-xl p-space-lg flex flex-col justify-between shadow-sm min-h-[148px]">
            <div className="flex items-center justify-between">
              <span className="font-label-md text-label-md text-on-surface-variant uppercase tracking-wider">
                Overall Risk Assessment
              </span>
            </div>
            <div className="flex items-baseline gap-space-md py-space-xs">
              <span className="font-metric-display text-metric-display text-error font-semibold tracking-tight">HIGH</span>
              <span className="font-metric-display text-metric-display text-on-surface font-semibold tracking-tight">0.78</span>
            </div>
            <div className="pt-space-sm border-t border-outline-variant/30 flex items-center justify-between">
              <span className="font-body-sm text-body-sm text-on-surface-variant">Severity</span>
              <span className="font-label-sm text-label-sm text-error font-medium">Critical Threshold (≥ {highThreshold.toFixed(2)})</span>
            </div>
          </div>

          {/* Card 2: Tracked Birds */}
          <div className="bg-surface-container-low border border-outline-variant/30 rounded-xl p-space-lg flex flex-col justify-between shadow-sm min-h-[148px]">
            <div className="flex items-center justify-between">
              <span className="font-label-md text-label-md text-on-surface-variant uppercase tracking-wider">
                Tracked Birds
              </span>
            </div>
            <div className="flex items-baseline py-space-xs">
              <span className="font-metric-display text-metric-display text-on-surface font-semibold tracking-tight">3</span>
            </div>
            <div className="pt-space-sm border-t border-outline-variant/30 flex items-center justify-between">
              <span className="font-body-sm text-body-sm text-on-surface-variant">Status</span>
              <span className="font-label-sm text-label-sm text-primary flex items-center gap-1">
                <span className="w-1.5 h-1.5 rounded-full bg-primary"></span> 3 Active Targets
              </span>
            </div>
          </div>

          {/* Card 3: Speed & Trajectory */}
          <div className="bg-surface-container-low border border-outline-variant/30 rounded-xl p-space-lg flex flex-col justify-between shadow-sm min-h-[148px]">
            <div className="flex items-center justify-between">
              <span className="font-label-md text-label-md text-on-surface-variant uppercase tracking-wider">
                Speed &amp; Trajectory
              </span>
            </div>
            <div className="flex items-baseline py-space-xs">
              <span className="font-metric-display text-metric-display text-on-surface font-semibold tracking-tight">
                48.2 <span className="font-body-sm text-body-sm text-on-surface-variant font-normal">km/h</span>
              </span>
            </div>
            <div className="pt-space-sm border-t border-outline-variant/30 flex items-center justify-between">
              <span className="font-body-sm text-body-sm text-on-surface-variant">Max Velocity</span>
              <span className="font-label-sm text-label-sm text-on-surface-variant font-medium">Track Vector 04</span>
            </div>
          </div>
        </div>

        {/* 2. Main Middle Section (2 Columns) */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-space-md items-stretch">
          {/* Left Column: Live Annotated Video Feed */}
          <div className="lg:col-span-7 bg-surface-container-low border border-outline-variant/30 rounded-xl p-space-md flex flex-col justify-between shadow-sm">
            <div className="flex items-center justify-between pb-space-sm mb-space-sm">
              <div className="flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-error animate-pulse"></span>
                <span className="font-headline-sm text-headline-sm text-on-surface font-semibold tracking-tight">
                  Live Camera Feed — {selectedCamera.name}
                </span>
              </div>
              <span className="font-label-sm text-label-sm text-on-surface-variant uppercase tracking-wider">
                Zone: Inner Approach
              </span>
            </div>

            {/* Video Frame with Overlays */}
            <div className="relative w-full aspect-video rounded-lg overflow-hidden bg-surface-container-lowest">
              <img
                className="w-full h-full object-cover"
                alt="A clear, realistic night-time operational airport runway wide angle perspective shot."
                src="https://lh3.googleusercontent.com/aida-public/AB6AXuAh7CnWcTUXcV6rX1Ay0VXBg4pO-DbngJ7DMMr1vvRPoqoIJZvv-ybmnwpQgI8tGI5JpO_emMjNRwkaZY9jQlA89TD8u5YdvgvNCfChGAR67hA9OSQrCirqGJoqQZuClW0cELxMH8E-RhV5h7aQPETBnwNQiHAKbU8OIMp8_RRa_YD2DQ7lC7FXkzg9g2tD6mAsBwmQ0jJnmf-usg1Aws-PPFab6HabgvzO25AkYiA"
              />
              {/* SVG Overlay for Runway Exclusion Zone & Bounding Boxes */}
              <svg className="absolute inset-0 w-full h-full pointer-events-none" preserveAspectRatio="none" viewBox="0 0 800 450">
                <polygon
                  fill="rgba(255, 122, 115, 0.08)"
                  points="120,390 320,170 480,170 680,390"
                  stroke="#ff7a73"
                  strokeDasharray="6,4"
                  strokeWidth="2"
                ></polygon>
                <text fill="#ff7a73" fontFamily="JetBrains Mono" fontSize="11" fontWeight="600" letterSpacing="0.06em" x="350" y="200">
                  RUNWAY EXCLUSION ZONE
                </text>
              </svg>

              {/* Bounding Box 1 (#B-104) */}
              <div className="absolute left-[36%] top-[42%] w-16 h-14 pointer-events-none">
                <div className="w-full h-full rounded-DEFAULT bg-error/15 border border-error"></div>
                <div className="absolute -top-6 left-0 bg-surface-container-lowest/90 px-1.5 py-0.5 rounded-DEFAULT whitespace-nowrap shadow-sm border border-outline-variant/30">
                  <span className="font-label-sm text-label-sm text-error font-medium">#B-104 · 48 km/h</span>
                </div>
              </div>

              {/* Bounding Box 2 (#B-108) */}
              <div className="absolute left-[52%] top-[48%] w-14 h-12 pointer-events-none">
                <div className="w-full h-full rounded-DEFAULT bg-secondary/15 border border-secondary"></div>
                <div className="absolute -top-6 left-0 bg-surface-container-lowest/90 px-1.5 py-0.5 rounded-DEFAULT whitespace-nowrap shadow-sm border border-outline-variant/30">
                  <span className="font-label-sm text-label-sm text-secondary font-medium">#B-108 · 39 km/h</span>
                </div>
              </div>

              {/* Bounding Box 3 (#B-112) */}
              <div className="absolute left-[62%] top-[34%] w-12 h-10 pointer-events-none">
                <div className="w-full h-full rounded-DEFAULT bg-secondary/15 border border-secondary"></div>
                <div className="absolute -top-6 left-0 bg-surface-container-lowest/90 px-1.5 py-0.5 rounded-DEFAULT whitespace-nowrap shadow-sm border border-outline-variant/30">
                  <span className="font-label-sm text-label-sm text-secondary font-medium">#B-112 · 24 km/h</span>
                </div>
              </div>

              {/* Bottom Left In-feed Status Label */}
              <div className="absolute bottom-3 left-3 bg-surface-container-lowest/90 px-2 py-1 rounded-DEFAULT border border-outline-variant/30">
                <span className="font-label-sm text-label-sm text-on-surface">OPTICAL PRIMARY · {selectedCamera.tag}</span>
              </div>
            </div>

            <div className="flex items-center justify-between pt-space-sm mt-space-xs font-label-sm text-label-sm text-on-surface-variant">
              <span>Field of View: {selectedCamera.name} Threshold to Touchdown</span>
              <span className="text-primary font-mono font-medium">1080p 60FPS</span>
            </div>
          </div>

          {/* Right Column: Factor Contributions Bar Chart */}
          <div className="lg:col-span-5 bg-surface-container-low border border-outline-variant/30 rounded-xl p-space-lg flex flex-col justify-between shadow-sm">
            <div>
              <div className="flex items-center justify-between pb-space-sm mb-space-md">
                <div>
                  <h2 className="font-headline-sm text-headline-sm text-on-surface font-semibold tracking-tight">
                    Factor Contributions
                  </h2>
                  <p className="font-body-sm text-body-sm text-on-surface-variant mt-0.5">
                    Weighted telemetry model impact
                  </p>
                </div>
              </div>

              {/* Factor 1: Runway Proximity */}
              <div className="flex flex-col gap-1.5 mb-space-md">
                <div className="flex justify-between items-baseline">
                  <div className="flex items-center gap-1.5">
                    <span className="font-body-md text-body-md text-on-surface font-medium">1. Runway Proximity</span>
                    <span className="font-label-sm text-label-sm text-error px-1.5 py-0.5 rounded-DEFAULT bg-error-container/20">
                      Primary Driver
                    </span>
                  </div>
                  <span className="font-label-md text-label-md text-error font-semibold">0.88</span>
                </div>
                <div className="w-full h-2 rounded-full bg-surface-container-highest overflow-hidden">
                  <div className="h-full bg-error rounded-full" style={{ width: '88%' }}></div>
                </div>
              </div>

              {/* Factor 2: Bird Count */}
              <div className="flex flex-col gap-1.5 mb-space-md">
                <div className="flex justify-between items-baseline">
                  <span className="font-body-md text-body-md text-on-surface font-medium">2. Bird Count</span>
                  <span className="font-label-md text-label-md text-secondary font-semibold">0.65</span>
                </div>
                <div className="w-full h-2 rounded-full bg-surface-container-highest overflow-hidden">
                  <div className="h-full bg-secondary rounded-full" style={{ width: '65%' }}></div>
                </div>
              </div>

              {/* Factor 3: Flock Size */}
              <div className="flex flex-col gap-1.5 mb-space-md">
                <div className="flex justify-between items-baseline">
                  <span className="font-body-md text-body-md text-on-surface font-medium">3. Flock Size</span>
                  <span className="font-label-md text-label-md text-secondary font-semibold">0.58</span>
                </div>
                <div className="w-full h-2 rounded-full bg-surface-container-highest overflow-hidden">
                  <div className="h-full bg-secondary rounded-full" style={{ width: '58%' }}></div>
                </div>
              </div>

              {/* Factor 4: Speed / Velocity */}
              <div className="flex flex-col gap-1.5 mb-space-md">
                <div className="flex justify-between items-baseline">
                  <span className="font-body-md text-body-md text-on-surface font-medium">4. Speed / Velocity</span>
                  <span className="font-label-md text-label-md text-secondary font-semibold">0.52</span>
                </div>
                <div className="w-full h-2 rounded-full bg-surface-container-highest overflow-hidden">
                  <div className="h-full bg-secondary rounded-full" style={{ width: '52%' }}></div>
                </div>
              </div>

              {/* Factor 5: Time of Day */}
              <div className="flex flex-col gap-1.5">
                <div className="flex justify-between items-baseline">
                  <span className="font-body-md text-body-md text-on-surface font-medium">5. Time of Day</span>
                  <span className="font-label-md text-label-md text-primary font-semibold">0.35</span>
                </div>
                <div className="w-full h-2 rounded-full bg-surface-container-highest overflow-hidden">
                  <div className="h-full bg-primary rounded-full" style={{ width: '35%' }}></div>
                </div>
              </div>
            </div>

            <div className="pt-space-md mt-space-md flex items-center justify-between text-on-surface-variant font-label-sm text-label-sm border-t border-outline-variant/30">
              <span>Zone sensitivity factor: +0.24</span>
              <span>Sum normalized: 3.03 / 5.00</span>
            </div>
          </div>
        </div>

        {/* 3. Bottom Section: Risk Over Time Chart */}
        <div className="w-full bg-surface-container-low border border-outline-variant/30 rounded-xl p-space-lg flex flex-col shadow-sm">
          <div className="flex flex-col md:flex-row md:items-center justify-between pb-space-sm mb-space-md gap-space-sm">
            <div>
              <h2 className="font-headline-sm text-headline-sm text-on-surface font-semibold tracking-tight">
                Risk Score Over Time (Last 15 Minutes)
              </h2>
              <p className="font-body-sm text-body-sm text-on-surface-variant mt-0.5">
                Continuous rolling probability progression
              </p>
            </div>
            {/* Legend */}
            <div className="flex items-center gap-space-md font-label-sm text-label-sm">
              <div className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-full bg-primary shrink-0"></span>
                <span className="text-on-surface-variant">Low (&lt; {medThreshold.toFixed(2)})</span>
              </div>
              <div className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-full bg-secondary shrink-0"></span>
                <span className="text-on-surface-variant">Medium ({medThreshold.toFixed(2)} - {highThreshold.toFixed(2)})</span>
              </div>
              <div className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-full bg-error shrink-0"></span>
                <span className="text-on-surface">High (≥ {highThreshold.toFixed(2)})</span>
              </div>
            </div>
          </div>

          {/* Minimal Clean SVG Line Graph */}
          <div className="w-full h-56 relative">
            <svg className="w-full h-full overflow-visible" preserveAspectRatio="none" viewBox="0 0 1000 220">
              {/* Background Grid lines */}
              <line stroke="#343535" strokeOpacity="0.3" strokeWidth="1" x1="60" x2="980" y1="180" y2="180"></line>
              <line stroke="#343535" strokeOpacity="0.3" strokeWidth="1" x1="60" x2="980" y1="120" y2="120"></line>
              <line stroke="#343535" strokeOpacity="0.3" strokeWidth="1" x1="60" x2="980" y1="60" y2="60"></line>

              {/* Medium Threshold line */}
              <line stroke="#ffb95f" strokeDasharray="4,4" strokeOpacity="0.8" strokeWidth="1" x1="60" x2="980" y1="146" y2="146"></line>
              <text fill="#ffb95f" fontFamily="JetBrains Mono" fontSize="10" fontWeight="500" x="64" y="141">
                Medium ({medThreshold.toFixed(2)})
              </text>

              {/* High Threshold line */}
              <line stroke="#ffb4ab" strokeDasharray="4,4" strokeOpacity="0.8" strokeWidth="1" x1="60" x2="980" y1="92" y2="92"></line>
              <text fill="#ffb4ab" fontFamily="JetBrains Mono" fontSize="10" fontWeight="500" x="64" y="87">
                High ({highThreshold.toFixed(2)})
              </text>

              {/* Baseline Reference (0.0) */}
              <line stroke="#343535" strokeWidth="1" x1="60" x2="980" y1="200" y2="200"></line>

              {/* Area Gradient under Curve */}
              <defs>
                <linearGradient id="riskGradient" x1="0%" x2="0%" y1="0%" y2="100%">
                  <stop offset="0%" stopColor="#ff7a73" stopOpacity="0.25"></stop>
                  <stop offset="60%" stopColor="#ffb95f" stopOpacity="0.10"></stop>
                  <stop offset="100%" stopColor="#4edea3" stopOpacity="0.0"></stop>
                </linearGradient>
              </defs>
              <path
                d="M 80,173 C 200,167 260,162 330,160 C 400,158 430,145 460,138 C 500,128 540,118 590,113 C 650,107 680,104 720,101 C 770,97 800,85 850,77 C 890,70 920,62 960,59 L 960,200 L 80,200 Z"
                fill="url(#riskGradient)"
              ></path>

              {/* Main Smooth Risk Curve */}
              <path
                d="M 80,173 C 200,167 260,162 330,160 C 400,158 430,145 460,138 C 500,128 540,118 590,113 C 650,107 680,104 720,101 C 770,97 800,85 850,77 C 890,70 920,62 960,59"
                fill="none"
                stroke="#ffb4ab"
                strokeLinecap="round"
                strokeWidth="2.5"
              ></path>

              {/* Key Data Points */}
              <circle cx="80" cy="173" fill="#4edea3" r="3"></circle>
              <circle cx="330" cy="160" fill="#4edea3" r="3"></circle>
              <circle cx="590" cy="113" fill="#ffb95f" r="3"></circle>
              <circle cx="850" cy="77" fill="#ffb4ab" r="3.5"></circle>

              {/* Current Peak Alert Marker (14:32) */}
              <circle className="animate-ping" cx="960" cy="59" fill="#ff7a73" fillOpacity="0.3" r="7"></circle>
              <circle cx="960" cy="59" fill="#ff7a73" r="4.5" stroke="#0d0e0f" strokeWidth="1.5"></circle>

              {/* Peak Value Callout Tag */}
              <g transform="translate(900, 24)">
                <rect fill="#1e2020" height="22" rx="2" stroke="#ff7a73" strokeWidth="1" width="70" x="0" y="0"></rect>
                <text fill="#ffb4ab" fontFamily="JetBrains Mono" fontSize="11" fontWeight="600" textAnchor="middle" x="35" y="15">
                  0.78 PEAK
                </text>
              </g>

              {/* Y-Axis Ticks / Labels */}
              <text fill="#86948a" fontFamily="JetBrains Mono" fontSize="10" textAnchor="end" x="45" y="203">0.00</text>
              <text fill="#86948a" fontFamily="JetBrains Mono" fontSize="10" textAnchor="end" x="45" y="149">0.30</text>
              <text fill="#86948a" fontFamily="JetBrains Mono" fontSize="10" textAnchor="end" x="45" y="95">0.60</text>
              <text fill="#86948a" fontFamily="JetBrains Mono" fontSize="10" textAnchor="end" x="45" y="40">1.00</text>

              {/* X-Axis Timestamps */}
              <text fill="#86948a" fontFamily="JetBrains Mono" fontSize="10" textAnchor="middle" x="80" y="216">14:18</text>
              <text fill="#86948a" fontFamily="JetBrains Mono" fontSize="10" textAnchor="middle" x="330" y="216">14:22</text>
              <text fill="#86948a" fontFamily="JetBrains Mono" fontSize="10" textAnchor="middle" x="590" y="216">14:26</text>
              <text fill="#86948a" fontFamily="JetBrains Mono" fontSize="10" textAnchor="middle" x="850" y="216">14:30</text>
              <text fill="#e3e2e2" fontFamily="JetBrains Mono" fontSize="10" fontWeight="600" textAnchor="middle" x="960" y="216">14:32 (Now)</text>
            </svg>
          </div>
          <div className="flex items-center justify-between pt-space-sm mt-space-sm font-label-sm text-label-sm text-on-surface-variant border-t border-outline-variant/30">
            <span>Sampling interval: 1.0 sec rolling average</span>
            <span>Runway Sector {selectedCamera.code} Approach Path</span>
          </div>
        </div>
      </div>
    </div>
  );
}

