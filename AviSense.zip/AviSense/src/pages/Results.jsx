import React from 'react';
import { BENCHMARK_FACTORS } from '../data/mockData';
import './Results.css';

export default function Results() {
  const handleExportCSV = () => {
    const headers = ['RISK COMPONENT FACTOR', 'MODEL WEIGHT (alpha)', 'ABLATION DELTA (mAP LOSS)', 'VARIANCE REGIME (%)', 'SEVERITY GRADE', 'STATUS'];
    const rows = BENCHMARK_FACTORS.map(f => [
      `"${f.name}"`,
      f.weight.toFixed(3),
      f.ablation,
      `${f.variancePercent}%`,
      `"${f.category}"`,
      f.status
    ]);
    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map(r => r.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', 'AviSense_Benchmark_Ablation_Matrix.csv');
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="flex flex-col w-full pb-space-xl results-container">
      {/* Page Header & Metadata Ribbon */}
      <div className="flex flex-col gap-space-md mb-space-lg">
        <div className="flex flex-col md:flex-row md:items-start justify-between gap-space-md">
          <div className="flex flex-col gap-space-xs">
            <div className="flex items-center gap-space-xs">
              <span className="font-label-sm text-label-sm uppercase px-1.5 py-0.5 rounded bg-surface-container text-outline">
                PAGE 05
              </span>
              <span className="text-outline font-label-sm text-label-sm">/</span>
              <span className="font-label-sm text-label-sm text-primary uppercase">
                OFFLINE EVALUATION SUITE
              </span>
            </div>
            <h1 className="font-headline-xl text-headline-xl text-on-surface tracking-tight font-semibold">
              Model Evaluation &amp; Benchmark Results
            </h1>
            <p className="font-body-md text-body-md text-on-surface-variant max-w-3xl">
              Validation figures, confusion matrix, precision-recall characteristics, and multi-task loss telemetry under FAA AC 150/5220-25 operational guidelines.
            </p>
          </div>
          <div className="flex items-center self-start gap-space-xs px-space-md py-space-sm rounded bg-surface-container-low shadow-sm border border-outline-variant/30">
            <span className="w-1.5 h-1.5 rounded-full bg-secondary"></span>
            <span className="font-label-sm text-label-sm text-secondary uppercase tracking-wider">
              [BENCHMARK CERTIFIED]
            </span>
          </div>
        </div>

        {/* Telemetry & Dataset Context Banner */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-space-sm p-space-sm bg-surface-container-low rounded-lg shadow-sm border border-outline-variant/30">
          <div className="flex items-center gap-space-xs px-space-sm py-1 bg-surface-container rounded">
            <span className="material-symbols-outlined text-outline text-sm">database</span>
            <div className="flex flex-col">
              <span className="font-label-sm text-label-sm text-on-surface-variant uppercase">DATASET CORPUS</span>
              <span className="font-label-sm text-label-sm text-on-surface font-medium">14,280 FRAMES / 4 REGIMES</span>
            </div>
          </div>
          <div className="flex items-center gap-space-xs px-space-sm py-1 bg-surface-container rounded">
            <span className="material-symbols-outlined text-outline text-sm">memory</span>
            <div className="flex flex-col">
              <span className="font-label-sm text-label-sm text-on-surface-variant uppercase">DEPLOYED WEIGHTS</span>
              <span className="font-label-sm text-label-sm text-primary font-medium">YOLOv8x-Avian-FineTune-v1.4</span>
            </div>
          </div>
          <div className="flex items-center gap-space-xs px-space-sm py-1 bg-surface-container rounded">
            <span className="material-symbols-outlined text-outline text-sm">wb_twilight</span>
            <div className="flex flex-col">
              <span className="font-label-sm text-label-sm text-on-surface-variant uppercase">EVALUATION CONDITIONS</span>
              <span className="font-label-sm text-label-sm text-on-surface">CLEAR • FOG • DUSK • SHIMMER</span>
            </div>
          </div>
          <div className="flex items-center gap-space-xs px-space-sm py-1 bg-surface-container rounded">
            <span className="material-symbols-outlined text-outline text-sm">verified_user</span>
            <div className="flex flex-col">
              <span className="font-label-sm text-label-sm text-on-surface-variant uppercase">INSPECTION LEVEL</span>
              <span className="font-label-sm text-label-sm text-primary">CERTIFIED TEST PROTOCOL</span>
            </div>
          </div>
        </div>
      </div>

      {/* Metric Pods (Streamlit st.metric Style) */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-space-md mb-space-xl">
        <div className="flex flex-col justify-between p-space-md bg-surface-container-low rounded-lg shadow-sm border border-outline-variant/30">
          <div className="flex justify-between items-start mb-space-xs">
            <span className="font-label-md text-label-md text-on-surface-variant">mAP@50-95</span>
            <span className="font-label-sm text-label-sm px-1.5 py-0.5 rounded bg-surface-container text-primary font-medium">
              +2.3% vs base
            </span>
          </div>
          <span className="font-metric-display text-metric-display text-on-surface font-semibold">91.4%</span>
          <div className="flex items-center gap-space-xs mt-space-sm">
            <span className="w-1.5 h-1.5 rounded-full bg-primary"></span>
            <span className="font-label-sm text-label-sm text-on-surface-variant">IoU 0.50:0.95 multi-scale target</span>
          </div>
        </div>

        <div className="flex flex-col justify-between p-space-md bg-surface-container-low rounded-lg shadow-sm border border-outline-variant/30">
          <div className="flex justify-between items-start mb-space-xs">
            <span className="font-label-md text-label-md text-on-surface-variant">Avian Detection Precision</span>
            <span className="font-label-sm text-label-sm px-1.5 py-0.5 rounded bg-surface-container text-on-surface-variant font-medium">
              FPR: 5.2%
            </span>
          </div>
          <span className="font-metric-display text-metric-display text-on-surface font-semibold">94.8%</span>
          <div className="flex items-center gap-space-xs mt-space-sm">
            <span className="w-1.5 h-1.5 rounded-full bg-primary"></span>
            <span className="font-label-sm text-label-sm text-on-surface-variant">Optimal operating pt: 0.42 thresh</span>
          </div>
        </div>

        <div className="flex flex-col justify-between p-space-md bg-surface-container-low rounded-lg shadow-sm border border-outline-variant/30">
          <div className="flex justify-between items-start mb-space-xs">
            <span className="font-label-md text-label-md text-on-surface-variant">Tracking Recall (MOTA)</span>
            <span className="font-label-sm text-label-sm px-1.5 py-0.5 rounded bg-surface-container text-primary font-medium">
              ID Sw: &lt;1.1%
            </span>
          </div>
          <span className="font-metric-display text-metric-display text-on-surface font-semibold">88.6%</span>
          <div className="flex items-center gap-space-xs mt-space-sm">
            <span className="w-1.5 h-1.5 rounded-full bg-primary"></span>
            <span className="font-label-sm text-label-sm text-on-surface-variant">ByteTrack association across occlusion</span>
          </div>
        </div>

        <div className="flex flex-col justify-between p-space-md bg-surface-container-low rounded-lg shadow-sm border border-outline-variant/30">
          <div className="flex justify-between items-start mb-space-xs">
            <span className="font-label-md text-label-md text-on-surface-variant">Inference Latency</span>
            <span className="font-label-sm text-label-sm px-1.5 py-0.5 rounded bg-surface-container text-secondary font-medium">
              54.3 FPS
            </span>
          </div>
          <span className="font-metric-display text-metric-display text-on-surface font-semibold">
            18.4 <span className="font-body-sm text-body-sm text-on-surface-variant font-normal">ms</span>
          </span>
          <div className="flex items-center gap-space-xs mt-space-sm">
            <span className="w-1.5 h-1.5 rounded-full bg-primary"></span>
            <span className="font-label-sm text-label-sm text-on-surface-variant">NVIDIA RTX A4000 TensorRT FP16</span>
          </div>
        </div>
      </div>

      {/* 2x2 Model Evaluation Visualizations Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-space-lg mb-space-xl">
        {/* Figure 1: Normalized Confusion Matrix */}
        <div className="flex flex-col bg-surface-container-low p-space-md rounded-lg shadow-sm border border-outline-variant/30">
          <div className="flex justify-between items-center pb-space-sm mb-space-sm">
            <div className="flex items-center gap-space-xs">
              <span className="font-label-sm text-label-sm text-primary uppercase">01 // MATRIX</span>
              <span className="font-headline-sm text-headline-sm text-on-surface font-semibold">
                Confusion Matrix (Normalized)
              </span>
            </div>
            <span className="font-label-sm text-label-sm text-on-surface-variant">N = 2,850 CLIPS</span>
          </div>
          <div className="flex flex-col items-center justify-center p-space-sm bg-surface-container-lowest rounded border border-outline-variant/20">
            {/* Matrix Visual */}
            <div className="w-full max-w-md flex flex-col gap-1">
              <div className="grid grid-cols-6 text-center font-label-sm text-label-sm text-outline pb-1 font-semibold">
                <span className="text-left font-label-sm text-label-sm text-on-surface-variant">TRUE \ PRED</span>
                <span>AVIAN</span>
                <span>FLOCK</span>
                <span>CLUTTER</span>
                <span>VEHICLE</span>
                <span>SHIMMER</span>
              </div>
              {/* Row 1: Avian */}
              <div className="grid grid-cols-6 items-center gap-1 text-center font-label-sm text-label-sm">
                <span className="text-left truncate font-label-sm text-label-sm text-on-surface-variant font-medium">Avian</span>
                <div className="bg-primary/90 text-on-primary font-bold py-2 rounded">0.96</div>
                <div className="bg-surface-container-high text-on-surface-variant py-2 rounded">0.03</div>
                <div className="bg-surface-container text-outline py-2 rounded">0.01</div>
                <div className="bg-surface-container text-outline py-2 rounded">0.00</div>
                <div className="bg-surface-container text-outline py-2 rounded">0.00</div>
              </div>
              {/* Row 2: Flock */}
              <div className="grid grid-cols-6 items-center gap-1 text-center font-label-sm text-label-sm">
                <span className="text-left truncate font-label-sm text-label-sm text-on-surface-variant font-medium">Flock</span>
                <div className="bg-surface-container-high text-on-surface-variant py-2 rounded">0.04</div>
                <div className="bg-primary/80 text-on-primary font-bold py-2 rounded">0.94</div>
                <div className="bg-surface-container text-outline py-2 rounded">0.01</div>
                <div className="bg-surface-container text-outline py-2 rounded">0.01</div>
                <div className="bg-surface-container text-outline py-2 rounded">0.00</div>
              </div>
              {/* Row 3: Clutter */}
              <div className="grid grid-cols-6 items-center gap-1 text-center font-label-sm text-label-sm">
                <span className="text-left truncate font-label-sm text-label-sm text-on-surface-variant font-medium">Clutter</span>
                <div className="bg-surface-container-high text-on-surface-variant py-2 rounded">0.02</div>
                <div className="bg-surface-container text-outline py-2 rounded">0.01</div>
                <div className="bg-primary/75 text-on-primary font-bold py-2 rounded">0.93</div>
                <div className="bg-surface-container-high text-on-surface-variant py-2 rounded">0.02</div>
                <div className="bg-surface-container-high text-on-surface-variant py-2 rounded">0.02</div>
              </div>
              {/* Row 4: Vehicle */}
              <div className="grid grid-cols-6 items-center gap-1 text-center font-label-sm text-label-sm">
                <span className="text-left truncate font-label-sm text-label-sm text-on-surface-variant font-medium">Vehicle</span>
                <div className="bg-surface-container text-outline py-2 rounded">0.01</div>
                <div className="bg-surface-container text-outline py-2 rounded">0.00</div>
                <div className="bg-surface-container text-outline py-2 rounded">0.01</div>
                <div className="bg-primary text-on-primary font-bold py-2 rounded">0.98</div>
                <div className="bg-surface-container text-outline py-2 rounded">0.00</div>
              </div>
              {/* Row 5: Shimmer */}
              <div className="grid grid-cols-6 items-center gap-1 text-center font-label-sm text-label-sm">
                <span className="text-left truncate font-label-sm text-label-sm text-on-surface-variant font-medium">Shimmer</span>
                <div className="bg-surface-container-high text-on-surface-variant py-2 rounded">0.03</div>
                <div className="bg-surface-container text-outline py-2 rounded">0.01</div>
                <div className="bg-surface-container-high text-on-surface-variant py-2 rounded">0.04</div>
                <div className="bg-surface-container text-outline py-2 rounded">0.00</div>
                <div className="bg-primary/70 text-on-primary font-bold py-2 rounded">0.92</div>
              </div>
            </div>
          </div>
          <div className="flex items-start gap-space-xs mt-space-sm pt-space-xs">
            <span className="material-symbols-outlined text-outline text-sm mt-0.5">info</span>
            <p className="font-body-sm text-body-sm text-on-surface-variant">
              <strong className="text-on-surface font-medium">Fig 1:</strong> 5-class normalized confusion matrix evaluated on 2,850 validation clips across day/crepuscular conditions. Shows nominal classification accuracy with minor shimmer cross-activation.
            </p>
          </div>
        </div>

        {/* Figure 2: Precision-Recall Curve */}
        <div className="flex flex-col bg-surface-container-low p-space-md rounded-lg shadow-sm border border-outline-variant/30">
          <div className="flex justify-between items-center pb-space-sm mb-space-sm">
            <div className="flex items-center gap-space-xs">
              <span className="font-label-sm text-label-sm text-primary uppercase">02 // PR CURVE</span>
              <span className="font-headline-sm text-headline-sm text-on-surface font-semibold">
                Precision-Recall Characteristic
              </span>
            </div>
            <span className="font-label-sm text-label-sm px-1.5 py-0.5 rounded bg-surface-container text-primary font-medium">
              mAP@50 = 0.941
            </span>
          </div>
          <div className="w-full h-56 bg-surface-container-lowest rounded p-space-sm relative flex flex-col justify-end border border-outline-variant/20">
            <svg className="w-full h-full overflow-visible" preserveAspectRatio="none" viewBox="0 0 400 180">
              {/* Grid lines */}
              <line className="text-surface-container-high" stroke="#343535" strokeDasharray="3,3" strokeWidth="1" x1="40" x2="380" y1="20" y2="20"></line>
              <line className="text-surface-container-high" stroke="#343535" strokeDasharray="3,3" strokeWidth="1" x1="40" x2="380" y1="60" y2="60"></line>
              <line className="text-surface-container-high" stroke="#343535" strokeDasharray="3,3" strokeWidth="1" x1="40" x2="380" y1="100" y2="100"></line>
              <line className="text-surface-container-high" stroke="#343535" strokeDasharray="3,3" strokeWidth="1" x1="40" x2="380" y1="140" y2="140"></line>
              {/* Axes */}
              <line stroke="#3c4a42" strokeWidth="1.5" x1="40" x2="380" y1="140" y2="140"></line>
              <line stroke="#3c4a42" strokeWidth="1.5" x1="40" x2="40" y1="20" y2="140"></line>
              {/* Ticks */}
              <text fill="#86948a" fontFamily="JetBrains Mono" fontSize="9" textAnchor="end" x="35" y="24">1.0</text>
              <text fill="#86948a" fontFamily="JetBrains Mono" fontSize="9" textAnchor="end" x="35" y="80">0.5</text>
              <text fill="#86948a" fontFamily="JetBrains Mono" fontSize="9" textAnchor="end" x="35" y="143">0.0</text>
              <text fill="#86948a" fontFamily="JetBrains Mono" fontSize="9" textAnchor="middle" x="40" y="156">0.0</text>
              <text fill="#86948a" fontFamily="JetBrains Mono" fontSize="9" textAnchor="middle" x="210" y="156">0.5 Recall</text>
              <text fill="#86948a" fontFamily="JetBrains Mono" fontSize="9" textAnchor="end" x="380" y="156">1.0</text>
              {/* Curves */}
              <path d="M 40,30 Q 180,35 260,70 T 380,135" fill="none" stroke="#86948a" strokeDasharray="4,4" strokeWidth="1.5"></path>
              <path d="M 40,24 Q 220,28 300,55 T 380,120" fill="none" stroke="#ffb95f" strokeWidth="2"></path>
              <path d="M 40,22 Q 260,25 330,48 T 380,105" fill="none" stroke="#4edea3" strokeWidth="2.5"></path>
              <circle cx="310" cy="42" fill="#4edea3" r="4"></circle>
              <line stroke="#4edea3" strokeDasharray="2,2" strokeOpacity="0.4" strokeWidth="1" x1="310" x2="310" y1="42" y2="140"></line>
            </svg>
            <div className="absolute top-2 right-3 flex items-center gap-space-sm bg-surface-container-high/90 px-space-sm py-1 rounded border border-outline-variant/30">
              <div className="flex items-center gap-1">
                <span className="w-2.5 h-0.5 bg-primary"></span>
                <span className="font-label-sm text-label-sm text-on-surface">Bird (0.95)</span>
              </div>
              <div className="flex items-center gap-1">
                <span className="w-2.5 h-0.5 bg-secondary"></span>
                <span className="font-label-sm text-label-sm text-on-surface">Flock (0.93)</span>
              </div>
              <div className="flex items-center gap-1">
                <span className="w-2.5 h-0.5 bg-outline border-b border-dashed border-outline"></span>
                <span className="font-label-sm text-label-sm text-on-surface-variant">Baseline</span>
              </div>
            </div>
          </div>
          <div className="flex items-start gap-space-xs mt-space-sm pt-space-xs">
            <span className="material-symbols-outlined text-outline text-sm mt-0.5">info</span>
            <p className="font-body-sm text-body-sm text-on-surface-variant">
              <strong className="text-on-surface font-medium">Fig 2:</strong> Precision-Recall trade-off curve across confidence thresholds [0.10 – 0.95]. Optimal operational F1 score stabilizes at 0.42 threshold with AUC = 0.941.
            </p>
          </div>
        </div>

        {/* Figure 3: Training & Validation Loss Progression */}
        <div className="flex flex-col bg-surface-container-low p-space-md rounded-lg shadow-sm border border-outline-variant/30">
          <div className="flex justify-between items-center pb-space-sm mb-space-sm">
            <div className="flex items-center gap-space-xs">
              <span className="font-label-sm text-label-sm text-primary uppercase">03 // CONVERGENCE</span>
              <span className="font-headline-sm text-headline-sm text-on-surface font-semibold">
                Multi-Task Loss Telemetry
              </span>
            </div>
            <span className="font-label-sm text-label-sm text-on-surface-variant">150 EPOCHS</span>
          </div>
          <div className="w-full h-56 bg-surface-container-lowest rounded p-space-sm relative flex flex-col justify-end border border-outline-variant/20">
            <svg className="w-full h-full overflow-visible" preserveAspectRatio="none" viewBox="0 0 400 180">
              <line stroke="#343535" strokeDasharray="3,3" strokeWidth="1" x1="40" x2="380" y1="20" y2="20"></line>
              <line stroke="#343535" strokeDasharray="3,3" strokeWidth="1" x1="40" x2="380" y1="60" y2="60"></line>
              <line stroke="#343535" strokeDasharray="3,3" strokeWidth="1" x1="40" x2="380" y1="100" y2="100"></line>
              <line stroke="#343535" strokeDasharray="3,3" strokeWidth="1" x1="40" x2="380" y1="140" y2="140"></line>
              <line stroke="#3c4a42" strokeWidth="1.5" x1="40" x2="380" y1="140" y2="140"></line>
              <line stroke="#3c4a42" strokeWidth="1.5" x1="40" x2="40" y1="20" y2="140"></line>
              <text fill="#86948a" fontFamily="JetBrains Mono" fontSize="9" textAnchor="end" x="35" y="24">2.5</text>
              <text fill="#86948a" fontFamily="JetBrains Mono" fontSize="9" textAnchor="end" x="35" y="80">1.2</text>
              <text fill="#86948a" fontFamily="JetBrains Mono" fontSize="9" textAnchor="end" x="35" y="143">0.1</text>
              <text fill="#86948a" fontFamily="JetBrains Mono" fontSize="9" textAnchor="middle" x="40" y="156">Ep 1</text>
              <text fill="#86948a" fontFamily="JetBrains Mono" fontSize="9" textAnchor="middle" x="210" y="156">Epoch 75</text>
              <text fill="#86948a" fontFamily="JetBrains Mono" fontSize="9" textAnchor="end" x="380" y="156">Epoch 150</text>
              <path d="M 40,40 Q 90,85 160,105 T 380,122" fill="none" stroke="#86948a" strokeWidth="1.5"></path>
              <path d="M 40,25 Q 100,80 180,110 T 380,128" fill="none" stroke="#ffb95f" strokeWidth="2"></path>
              <path d="M 40,30 Q 120,95 200,120 T 380,132" fill="none" stroke="#4edea3" strokeWidth="2"></path>
            </svg>
            <div className="absolute top-2 right-3 flex items-center gap-space-sm bg-surface-container-high/90 px-space-sm py-1 rounded border border-outline-variant/30">
              <div className="flex items-center gap-1">
                <span className="w-2.5 h-0.5 bg-primary"></span>
                <span className="font-label-sm text-label-sm text-on-surface">Box Loss</span>
              </div>
              <div className="flex items-center gap-1">
                <span className="w-2.5 h-0.5 bg-secondary"></span>
                <span className="font-label-sm text-label-sm text-on-surface">Cls Loss</span>
              </div>
              <div className="flex items-center gap-1">
                <span className="w-2.5 h-0.5 bg-outline"></span>
                <span className="font-label-sm text-label-sm text-on-surface">DFL Loss</span>
              </div>
            </div>
          </div>
          <div className="flex items-start gap-space-xs mt-space-sm pt-space-xs">
            <span className="material-symbols-outlined text-outline text-sm mt-0.5">info</span>
            <p className="font-body-sm text-body-sm text-on-surface-variant">
              <strong className="text-on-surface font-medium">Fig 3:</strong> Multi-task loss convergence curves across 150 training epochs on tarmac imagery. Smooth descent without degradation demonstrates robust generalization.
            </p>
          </div>
        </div>

        {/* Figure 4: Risk Score Calibration & Validation */}
        <div className="flex flex-col bg-surface-container-low p-space-md rounded-lg shadow-sm border border-outline-variant/30">
          <div className="flex justify-between items-center pb-space-sm mb-space-sm">
            <div className="flex items-center gap-space-xs">
              <span className="font-label-sm text-label-sm text-primary uppercase">04 // CALIBRATION</span>
              <span className="font-headline-sm text-headline-sm text-on-surface font-semibold">
                Risk Probability Calibration
              </span>
            </div>
            <span className="font-label-sm text-label-sm px-1.5 py-0.5 rounded bg-surface-container text-primary font-medium">
              ECE: 0.038
            </span>
          </div>
          <div className="w-full h-56 bg-surface-container-lowest rounded p-space-sm relative flex flex-col justify-end border border-outline-variant/20">
            <svg className="w-full h-full overflow-visible" preserveAspectRatio="none" viewBox="0 0 400 180">
              <line stroke="#343535" strokeDasharray="3,3" strokeWidth="1" x1="40" x2="380" y1="20" y2="20"></line>
              <line stroke="#343535" strokeDasharray="3,3" strokeWidth="1" x1="40" x2="380" y1="60" y2="60"></line>
              <line stroke="#343535" strokeDasharray="3,3" strokeWidth="1" x1="40" x2="380" y1="100" y2="100"></line>
              <line stroke="#343535" strokeDasharray="3,3" strokeWidth="1" x1="40" x2="380" y1="140" y2="140"></line>
              <line stroke="#3c4a42" strokeWidth="1.5" x1="40" x2="380" y1="140" y2="140"></line>
              <line stroke="#3c4a42" strokeWidth="1.5" x1="40" x2="40" y1="20" y2="140"></line>
              {/* Perfect 45-deg line */}
              <line stroke="#86948a" strokeDasharray="4,4" strokeWidth="1.5" x1="40" x2="380" y1="140" y2="20"></line>
              {/* Calibration Curve */}
              <path d="M 40,140 L 74,129 L 108,118 L 142,102 L 176,92 L 210,79 L 244,65 L 278,54 L 312,41 L 346,31 L 380,21" fill="none" stroke="#4edea3" strokeWidth="2"></path>
              <circle cx="74" cy="129" fill="#4edea3" r="3"></circle>
              <circle cx="142" cy="102" fill="#4edea3" r="3"></circle>
              <circle cx="210" cy="79" fill="#4edea3" r="3"></circle>
              <circle cx="278" cy="54" fill="#4edea3" r="3"></circle>
              <circle cx="346" cy="31" fill="#4edea3" r="3"></circle>
              <polygon fill="#4edea3" fillOpacity="0.1" points="40,140 380,18 380,26 40,140"></polygon>
              <text fill="#86948a" fontFamily="JetBrains Mono" fontSize="9" textAnchor="end" x="35" y="24">1.0</text>
              <text fill="#86948a" fontFamily="JetBrains Mono" fontSize="9" textAnchor="end" x="35" y="80">0.5</text>
              <text fill="#86948a" fontFamily="JetBrains Mono" fontSize="9" textAnchor="end" x="35" y="143">0.0</text>
              <text fill="#86948a" fontFamily="JetBrains Mono" fontSize="9" textAnchor="middle" x="40" y="156">0.0</text>
              <text fill="#86948a" fontFamily="JetBrains Mono" fontSize="9" textAnchor="middle" x="210" y="156">Predicted Risk Prob</text>
              <text fill="#86948a" fontFamily="JetBrains Mono" fontSize="9" textAnchor="end" x="380" y="156">1.0</text>
            </svg>
            <div className="absolute top-2 right-3 flex items-center gap-space-sm bg-surface-container-high/90 px-space-sm py-1 rounded border border-outline-variant/30">
              <div className="flex items-center gap-1">
                <span className="w-2.5 h-0.5 bg-primary"></span>
                <span className="font-label-sm text-label-sm text-on-surface">AviSense Model</span>
              </div>
              <div className="flex items-center gap-1">
                <span className="w-2.5 h-0.5 bg-outline border-b border-dashed border-outline"></span>
                <span className="font-label-sm text-label-sm text-on-surface-variant">Ideal 45°</span>
              </div>
            </div>
          </div>
          <div className="flex items-start gap-space-xs mt-space-sm pt-space-xs">
            <span className="material-symbols-outlined text-outline text-sm mt-0.5">info</span>
            <p className="font-body-sm text-body-sm text-on-surface-variant">
              <strong className="text-on-surface font-medium">Fig 4:</strong> Risk engine reliability calibration diagram comparing estimated hazard index against empirical incident logs. Maximum variance maintains within 4.2% margin.
            </p>
          </div>
        </div>
      </div>

      {/* Ablation / Factor Weight Contribution Section */}
      <div className="flex flex-col bg-surface-container-low p-space-md rounded-lg shadow-sm border border-outline-variant/30">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-space-xs pb-space-sm mb-space-sm">
          <div className="flex items-center gap-space-xs">
            <span className="font-label-sm text-label-sm text-primary uppercase">FACTOR DRIFT</span>
            <span className="font-headline-sm text-headline-sm text-on-surface font-semibold">
              Ablation &amp; Feature Weight Contribution Matrix
            </span>
          </div>
          <div className="flex items-center gap-space-xs">
            <span className="font-label-sm text-label-sm text-on-surface-variant">ANALYSIS PROTOCOL:</span>
            <span className="font-label-sm text-label-sm text-primary font-medium">ICAO EUR DOC 015 COMPLIANT</span>
          </div>
        </div>

        {/* Data Table */}
        <div className="overflow-x-auto w-full">
          <table className="w-full text-left font-body-sm text-body-sm">
            <thead className="bg-surface-container font-label-sm text-label-sm text-outline uppercase">
              <tr>
                <th className="py-2.5 px-space-md font-medium">RISK COMPONENT FACTOR</th>
                <th className="py-2.5 px-space-md text-right font-medium">MODEL WEIGHT (α)</th>
                <th className="py-2.5 px-space-md text-right font-medium">ABLATION Δ (mAP LOSS)</th>
                <th className="py-2.5 px-space-md font-medium">VARIANCE REGIME</th>
                <th className="py-2.5 px-space-md font-medium">ICAO/FAA SEVERITY GRADE</th>
                <th className="py-2.5 px-space-md text-right font-medium">STATUS</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-surface-container font-label-md text-label-md">
              {BENCHMARK_FACTORS.map((item, idx) => (
                <tr key={idx} className="hover:bg-surface-container/60 transition-colors">
                  <td className="py-3 px-space-md font-medium text-on-surface flex items-center gap-space-xs">
                    <span className={`material-symbols-outlined text-sm ${item.iconColor}`}>{item.icon}</span>
                    <span>{item.name}</span>
                  </td>
                  <td className="py-3 px-space-md text-right text-on-surface font-mono">{item.weight.toFixed(3)}</td>
                  <td className={`py-3 px-space-md text-right ${item.ablationColor} font-medium font-mono`}>{item.ablation}</td>
                  <td className="py-3 px-space-md">
                    <div className="w-28 bg-surface-container-highest rounded-full h-1.5 overflow-hidden">
                      <div className={`${item.varianceColor} h-full`} style={{ width: `${item.variancePercent}%` }}></div>
                    </div>
                  </td>
                  <td className="py-3 px-space-md">
                    <span className={`font-label-sm text-label-sm px-2 py-0.5 rounded font-medium ${item.categoryClass}`}>
                      {item.category}
                    </span>
                  </td>
                  <td className="py-3 px-space-md text-right">
                    <span className="font-label-sm text-label-sm text-primary font-semibold">{item.status}</span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Export & System Action Footer */}
        <div className="flex flex-col sm:flex-row justify-between items-center gap-space-sm mt-space-md pt-space-sm bg-surface-container-lowest p-space-sm rounded border border-outline-variant/30">
          <div className="flex items-center gap-space-xs text-outline font-label-sm text-label-sm">
            <span className="material-symbols-outlined text-sm">terminal</span>
            <span>RUN_ID: EVAL-2024-Q3-0914-RUNWAY18L // CHECKSUM: 98a3f89e1</span>
          </div>
          <div className="flex items-center gap-space-sm">
            <button
              onClick={handleExportCSV}
              className="h-8 px-space-md bg-surface-container hover:bg-surface-container-high text-on-surface rounded font-label-md text-label-md flex items-center gap-space-xs transition-colors cursor-pointer border border-outline-variant/30"
              type="button"
            >
              <span className="material-symbols-outlined text-sm">download</span>
              <span>EXPORT CSV</span>
            </button>
            <button
              onClick={handlePrint}
              className="h-8 px-space-md bg-primary hover:bg-primary-fixed-dim text-on-primary rounded font-label-md text-label-md font-medium flex items-center gap-space-xs transition-colors cursor-pointer"
              type="button"
            >
              <span className="material-symbols-outlined text-sm">print</span>
              <span>PRINT BENCHMARK REPORT</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

