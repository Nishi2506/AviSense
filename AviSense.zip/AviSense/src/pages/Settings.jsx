import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import './Settings.css';

export default function Settings() {
  const {
    selectedCamera,
    medThreshold,
    setMedThreshold,
    highThreshold,
    setHighThreshold,
    weights,
    setWeights,
    audioAlertEnabled,
    setAudioAlertEnabled,
    cooldownSeconds,
    setCooldownSeconds,
    selectedPreset,
    setSelectedPreset
  } = useApp();

  const [samplingRate, setSamplingRate] = useState(60);
  const [rtspUrl, setRtspUrl] = useState('cam04-rwy18l.airfield.internal:554/live/h264');
  const [saveStatus, setSaveStatus] = useState('');
  const [testDispatchStatus, setTestDispatchStatus] = useState('');
  const [testZoneStatus, setTestZoneStatus] = useState('');

  // Handle preset selection
  const handlePreset = (preset) => {
    setSelectedPreset(preset);
    if (preset === 'conservative') {
      setMedThreshold(0.20);
      setHighThreshold(0.50);
    } else if (preset === 'standard') {
      setMedThreshold(0.30);
      setHighThreshold(0.60);
    } else if (preset === 'reduced') {
      setMedThreshold(0.40);
      setHighThreshold(0.70);
    }
  };

  // Slider change handlers with constraints
  const handleMedChange = (e) => {
    const val = parseFloat(e.target.value);
    if (val >= highThreshold) {
      setHighThreshold(parseFloat((val + 0.05).toFixed(2)));
    }
    setMedThreshold(val);
  };

  const handleHighChange = (e) => {
    const val = parseFloat(e.target.value);
    if (val <= medThreshold) {
      setMedThreshold(parseFloat((val - 0.05).toFixed(2)));
    }
    setHighThreshold(val);
  };

  // Calculate dynamic band widths
  const lowWidth = medThreshold * 100;
  const medWidth = Math.max(0, (highThreshold - medThreshold) * 100);
  const highWidth = Math.max(0, (1 - highThreshold) * 100);

  // Weight handler
  const handleWeightChange = (key, val) => {
    setWeights(prev => ({
      ...prev,
      [key]: parseInt(val, 10)
    }));
  };

  const totalWeights = weights.w1 + weights.w2 + weights.w3 + weights.w4 + weights.w5;
  const isNormalized = totalWeights === 100;

  const handleTestDispatch = () => {
    setTestDispatchStatus('Dispatching dry run packet across tower bus...');
    setTimeout(() => {
      setTestDispatchStatus('Test Broadcast Acknowledged: KDEN-TWR REC-OK');
      setTimeout(() => setTestDispatchStatus(''), 4000);
    }, 1000);
  };

  const handleSaveGeometry = () => {
    setSaveStatus('Saving WGS-84 coordinate geometry to persistent sector store...');
    setTimeout(() => {
      setSaveStatus('Geometry bounds saved successfully');
      setTimeout(() => setSaveStatus(''), 3000);
    }, 800);
  };

  const handleTestZone = () => {
    setTestZoneStatus('Running raycast intersection across approach polygon...');
    setTimeout(() => {
      setTestZoneStatus('Intersection OK: 0 spurious breaches in current corridor');
      setTimeout(() => setTestZoneStatus(''), 3500);
    }, 700);
  };

  return (
    <div className="flex flex-col w-full pb-space-xl settings-container">
      {/* Top Operational Banner & Meta Header */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-space-md py-space-md border-b border-[#242828] pb-space-md mb-space-md">
        <div className="flex flex-col gap-space-xs">
          <div className="flex items-center gap-space-sm">
            <span className="font-label-sm text-label-sm px-space-xs py-0.5 rounded bg-surface-container-high text-primary uppercase tracking-widest">
              MODULE 06
            </span>
            <span className="font-label-sm text-label-sm text-outline">
              SYS.PARAM // CALIBRATION_BUILD_v4.2
            </span>
          </div>
          <h1 className="font-headline-lg text-headline-lg text-on-surface tracking-tight font-semibold">
            Runway Zone Viewer &amp; Operational Settings
          </h1>
          <p className="font-body-md text-body-md text-on-surface-variant max-w-3xl">
            Configure camera feeds, runway exclusion zones, threshold boundaries, and alert dispatch parameters.
          </p>
        </div>
        <div className="flex items-center gap-space-sm self-start lg:self-center">
          <div className="px-space-md py-space-xs rounded bg-surface-container-high text-secondary flex items-center gap-space-xs border border-outline-variant/30">
            <span className="material-symbols-outlined text-sm">tune</span>
            <span className="font-label-sm text-label-sm tracking-wider uppercase">[ACTIVE SYSTEM CONFIG]</span>
          </div>
        </div>
      </div>

      {/* Primary Architecture: 12-Column Responsive Layout */}
      <div className="grid grid-cols-12 gap-gutter-desktop mt-space-md">
        {/* LEFT COLUMN: Runway Exclusion Zone Editor & Ingest Config (Col 1-7) */}
        <div className="col-span-12 xl:col-span-7 flex flex-col gap-gutter-desktop">
          {/* Interactive Runway-Zone Viewer Card */}
          <div className="bg-surface rounded-xl overflow-hidden shadow-sm flex flex-col border border-outline-variant/30">
            {/* Panel Header */}
            <div className="px-space-md py-space-sm bg-surface-container-low flex items-center justify-between border-b border-outline-variant/30">
              <div className="flex items-center gap-space-sm">
                <span className="w-2 h-2 rounded-full bg-primary-container animate-pulse"></span>
                <span className="font-label-md text-label-md text-on-surface uppercase font-medium">
                  {selectedCamera.tag} FEED REPROJECTION ({selectedCamera.name.toUpperCase()})
                </span>
              </div>
              <div className="flex items-center gap-space-xs">
                <span className="font-label-sm text-label-sm text-outline font-mono">
                  FOV: 84.2° | AZIMUTH: 182° MAG
                </span>
              </div>
            </div>

            {/* Viewport Container with Polygon SVG Overlay */}
            <div className="relative w-full aspect-[16/9] bg-surface-container-lowest overflow-hidden select-none group">
              <img
                alt="Runway Surveillance Stream"
                className="w-full h-full object-cover filter contrast-[1.05]"
                src="https://lh3.googleusercontent.com/aida/ALJJyrBDq5kKnZNaFoPIngFmJe5-LmRVzPQ--lktcR_f25yuznyt_ajzv05H7BvKF6mELCuiF_Kew45r85T1nfotuYrpTzddsqMS70_Es8xo128ia9ZP-wUUcJjAmzhijs17Mk14aqyxdLyShHqE9sw82igOQHA8keYQeMlzfAORtUlA3NlyO5gg5DfPUUhri1rSS73m9vOIvbQ2AkpUy8CW38G9Xdsre759xZRHooO-cz4"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-surface-container-lowest/80 via-transparent to-surface-container-lowest/30 pointer-events-none"></div>

              {/* SVG Polygon Geometry Canvas */}
              <svg className="absolute inset-0 w-full h-full pointer-events-none" preserveAspectRatio="none" viewBox="0 0 1000 562">
                {/* Outer Approach Buffer */}
                <polygon
                  fill="#f59e0b"
                  fillOpacity="0.08"
                  points="120,490 340,190 660,190 890,490"
                  stroke="#f59e0b"
                  strokeDasharray="6,4"
                  strokeWidth="2"
                  vectorEffect="non-scaling-stroke"
                ></polygon>

                {/* Inner Runway Exclusion Zone */}
                <polygon
                  fill="#ef4444"
                  fillOpacity="0.18"
                  points="210,480 395,210 605,210 790,480"
                  stroke="#ef4444"
                  strokeWidth="2.5"
                  vectorEffect="non-scaling-stroke"
                ></polygon>

                {/* Centerline alignment track */}
                <line
                  opacity="0.6"
                  stroke="#4edea3"
                  strokeDasharray="4,6"
                  strokeWidth="1.5"
                  vectorEffect="non-scaling-stroke"
                  x1="500"
                  x2="500"
                  y1="210"
                  y2="480"
                ></line>

                {/* Anchor Vertices */}
                <g className="pointer-events-auto cursor-pointer">
                  <circle cx="210" cy="480" fill="#ef4444" r="5" stroke="#ffffff" strokeWidth="1.5"></circle>
                  <text fill="#ffffff" fontFamily="JetBrains Mono" fontSize="11" fontWeight="600" x="180" y="475">
                    P1 [39.8561°N, -104.6737°W]
                  </text>
                </g>
                <g className="pointer-events-auto cursor-pointer">
                  <circle cx="395" cy="210" fill="#ef4444" r="5" stroke="#ffffff" strokeWidth="1.5"></circle>
                  <text fill="#ffffff" fontFamily="JetBrains Mono" fontSize="11" fontWeight="600" x="245" y="200">
                    P2 [THR {selectedCamera.code} LT]
                  </text>
                </g>
                <g className="pointer-events-auto cursor-pointer">
                  <circle cx="605" cy="210" fill="#ef4444" r="5" stroke="#ffffff" strokeWidth="1.5"></circle>
                  <text fill="#ffffff" fontFamily="JetBrains Mono" fontSize="11" fontWeight="600" x="615" y="200">
                    P3 [THR {selectedCamera.code} RT]
                  </text>
                </g>
                <g className="pointer-events-auto cursor-pointer">
                  <circle cx="790" cy="480" fill="#ef4444" r="5" stroke="#ffffff" strokeWidth="1.5"></circle>
                  <text fill="#ffffff" fontFamily="JetBrains Mono" fontSize="11" fontWeight="600" x="710" y="475">
                    P4 [TDZ +300m]
                  </text>
                </g>
              </svg>

              {/* Top-Left Telemetry Tags */}
              <div className="absolute top-space-sm left-space-sm flex flex-col gap-1 pointer-events-none">
                <span className="font-label-sm text-label-sm px-space-xs py-0.5 rounded bg-surface-container-lowest/90 text-primary-fixed uppercase backdrop-blur-md border border-outline-variant/30">
                  CALIB-SURVEY: WGS-84 OK
                </span>
                <span className="font-label-sm text-label-sm px-space-xs py-0.5 rounded bg-surface-container-lowest/90 text-outline uppercase backdrop-blur-md border border-outline-variant/30">
                  GEO-FENCE: ACTIVE
                </span>
              </div>

              {/* Bottom Warning Legend */}
              <div className="absolute bottom-space-sm right-space-sm flex items-center gap-space-xs pointer-events-none">
                <span className="font-label-sm text-label-sm px-space-xs py-0.5 rounded bg-surface-container-lowest/90 text-secondary uppercase backdrop-blur-md flex items-center gap-1 border border-outline-variant/30">
                  <span className="w-1.5 h-1.5 rounded-full bg-secondary"></span> 350m Outer Buffer
                </span>
                <span className="font-label-sm text-label-sm px-space-xs py-0.5 rounded bg-surface-container-lowest/90 text-tertiary-container uppercase backdrop-blur-md flex items-center gap-1 border border-outline-variant/30">
                  <span className="w-1.5 h-1.5 rounded-full bg-tertiary-container"></span> Inner TDZ Exclusion
                </span>
              </div>
            </div>

            {/* Zone Metadata Chip & Specs */}
            <div className="px-space-md py-space-sm bg-surface-container flex flex-wrap items-center justify-between gap-space-xs border-t border-outline-variant/30">
              <div className="flex items-center gap-space-xs">
                <span className="material-symbols-outlined text-outline text-base">square_foot</span>
                <span className="font-label-sm text-label-sm text-on-surface">
                  Active Geometry: <strong className="text-primary-fixed">Sector {selectedCamera.code} Inner Box (1,200m × 75m)</strong>
                </span>
              </div>
              <div className="flex items-center gap-space-sm font-label-sm text-label-sm text-on-surface-variant">
                <span>Altitude Cap: <span className="text-on-surface font-mono">450 ft AGL</span></span>
                <span className="text-outline">/</span>
                <span>Elevation: <span className="text-on-surface font-mono">5,431 ft MSL</span></span>
              </div>
            </div>

            {/* Control Action Bar */}
            <div className="p-space-md bg-surface-container-low flex flex-wrap items-center justify-between gap-space-sm border-t border-outline-variant/30">
              <div className="flex flex-wrap items-center gap-space-xs">
                <button
                  onClick={handleTestZone}
                  className="h-8 px-space-md bg-surface-container-high hover:bg-surface-variant text-secondary rounded font-label-md text-label-md flex items-center gap-space-xs transition-colors cursor-pointer border border-outline-variant/30"
                  type="button"
                >
                  <span className="material-symbols-outlined text-sm">radar</span>
                  <span>Test Zone Intersect</span>
                </button>
                <button
                  onClick={() => {
                    setMedThreshold(0.30);
                    setHighThreshold(0.60);
                  }}
                  className="h-8 px-space-md bg-surface-container-high hover:bg-surface-variant text-on-surface rounded font-label-md text-label-md flex items-center gap-space-xs transition-colors cursor-pointer border border-outline-variant/30"
                  type="button"
                >
                  <span className="material-symbols-outlined text-sm">history</span>
                  <span>Reset to Survey</span>
                </button>
              </div>
              <button
                onClick={handleSaveGeometry}
                className="h-8 px-space-lg bg-on-surface text-surface rounded font-label-md text-label-md font-medium hover:bg-surface-variant hover:text-on-surface transition-colors flex items-center gap-space-xs cursor-pointer shadow"
                type="button"
              >
                <span className="material-symbols-outlined text-sm">save</span>
                <span>Save Geometry</span>
              </button>
            </div>

            {saveStatus && (
              <div className="px-space-md py-1.5 bg-primary/10 border-t border-primary/30 text-primary font-label-sm text-label-sm flex items-center gap-2">
                <span className="material-symbols-outlined text-sm">check_circle</span>
                <span>{saveStatus}</span>
              </div>
            )}
            {testZoneStatus && (
              <div className="px-space-md py-1.5 bg-secondary/10 border-t border-secondary/30 text-secondary font-label-sm text-label-sm flex items-center gap-2">
                <span className="material-symbols-outlined text-sm">info</span>
                <span>{testZoneStatus}</span>
              </div>
            )}
          </div>

          {/* Sensor Feed & Video Ingest Configuration */}
          <div className="bg-surface rounded-xl p-space-lg shadow-sm flex flex-col gap-space-md border border-outline-variant/30">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-space-sm">
                <span className="material-symbols-outlined text-outline">settings_ethernet</span>
                <h2 className="font-headline-sm text-headline-sm text-on-surface font-semibold">Video Ingest &amp; Sensor Pipeline</h2>
              </div>
              <span className="font-label-sm text-label-sm text-primary uppercase font-mono">PIPE: ZERO_DROP</span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-12 gap-space-md pt-space-xs">
              {/* RTSP URL */}
              <div className="md:col-span-8 flex flex-col gap-space-xs">
                <label className="font-label-sm text-label-sm text-on-surface-variant uppercase">
                  RTSP High-Res Surveillance Feed
                </label>
                <div className="flex items-center bg-surface-container rounded px-space-sm border border-outline-variant/30">
                  <span className="font-label-sm text-label-sm text-outline select-none font-mono">rtsp://</span>
                  <input
                    className="w-full bg-transparent py-2 px-space-xs font-label-md text-label-md text-on-surface focus:outline-none"
                    type="text"
                    value={rtspUrl}
                    onChange={(e) => setRtspUrl(e.target.value)}
                  />
                  <span className="material-symbols-outlined text-primary text-sm">check_circle</span>
                </div>
              </div>

              {/* Ingest Mode */}
              <div className="md:col-span-4 flex flex-col gap-space-xs">
                <label className="font-label-sm text-label-sm text-on-surface-variant uppercase">
                  Decoder Acceleration
                </label>
                <div className="h-10 bg-surface-container rounded px-space-sm flex items-center justify-between border border-outline-variant/30">
                  <span className="font-label-md text-label-md text-on-surface">NVDEC HW Accel</span>
                  <span className="material-symbols-outlined text-outline text-sm">memory</span>
                </div>
              </div>

              {/* Frame Rate Sampling */}
              <div className="md:col-span-6 flex flex-col gap-space-xs">
                <label className="font-label-sm text-label-sm text-on-surface-variant uppercase">
                  Inference Sampling Rate
                </label>
                <div className="grid grid-cols-2 gap-space-xs">
                  <button
                    onClick={() => setSamplingRate(30)}
                    className={`h-9 rounded font-label-md text-label-md transition-colors cursor-pointer border border-outline-variant/30 ${
                      samplingRate === 30
                        ? 'bg-surface-container-high text-primary font-medium'
                        : 'bg-surface-container text-on-surface-variant hover:bg-surface-container-high'
                    }`}
                    type="button"
                  >
                    30 FPS (Eco)
                  </button>
                  <button
                    onClick={() => setSamplingRate(60)}
                    className={`h-9 rounded font-label-md text-label-md transition-colors flex items-center justify-center gap-1 cursor-pointer border border-outline-variant/30 ${
                      samplingRate === 60
                        ? 'bg-surface-container-high text-primary font-medium'
                        : 'bg-surface-container text-on-surface-variant hover:bg-surface-container-high'
                    }`}
                    type="button"
                  >
                    <span className="w-1.5 h-1.5 rounded-full bg-primary"></span> 60 FPS (Active)
                  </button>
                </div>
              </div>

              {/* Stream Sync Delta */}
              <div className="md:col-span-6 flex flex-col gap-space-xs">
                <label className="font-label-sm text-label-sm text-on-surface-variant uppercase">
                  Network Protocol Handshake
                </label>
                <div className="h-9 bg-surface-container rounded px-space-md flex items-center justify-between text-on-surface-variant font-label-sm text-label-sm border border-outline-variant/30">
                  <span>TCP Transmit (Jitter Free)</span>
                  <span className="text-primary font-mono">{selectedCamera.latency}</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* RIGHT COLUMN: Risk Calibration, Weight Tuning & ATC Dispatch (Col 8-12) */}
        <div className="col-span-12 xl:col-span-5 flex flex-col gap-gutter-desktop">
          {/* Risk Threshold Calibration Card */}
          <div className="bg-surface rounded-xl p-space-lg shadow-sm flex flex-col gap-space-md border border-outline-variant/30">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-space-sm">
                <span className="material-symbols-outlined text-outline">tune</span>
                <h2 className="font-headline-sm text-headline-sm text-on-surface font-semibold">
                  Risk Threshold Calibration
                </h2>
              </div>
              <span className="font-label-sm text-label-sm text-outline font-mono">STD-OPS v2</span>
            </div>

            {/* Presets Selection Bar */}
            <div className="flex flex-col gap-space-xs">
              <span className="font-label-sm text-label-sm text-on-surface-variant uppercase">
                Operational Sensitivity Presets
              </span>
              <div className="grid grid-cols-3 gap-space-xs p-1 bg-surface-container-lowest rounded-lg border border-outline-variant/30">
                <button
                  onClick={() => handlePreset('conservative')}
                  className={`py-1.5 px-space-xs text-center rounded font-label-sm text-label-sm transition-colors cursor-pointer ${
                    selectedPreset === 'conservative'
                      ? 'bg-surface-container-high text-primary font-medium'
                      : 'text-on-surface-variant hover:text-on-surface'
                  }`}
                  type="button"
                >
                  Conservative
                </button>
                <button
                  onClick={() => handlePreset('standard')}
                  className={`py-1.5 px-space-xs text-center rounded font-label-sm text-label-sm transition-colors cursor-pointer ${
                    selectedPreset === 'standard'
                      ? 'bg-surface-container-high text-primary font-medium'
                      : 'text-on-surface-variant hover:text-on-surface'
                  }`}
                  type="button"
                >
                  Standard ({selectedCamera.code})
                </button>
                <button
                  onClick={() => handlePreset('reduced')}
                  className={`py-1.5 px-space-xs text-center rounded font-label-sm text-label-sm transition-colors cursor-pointer ${
                    selectedPreset === 'reduced'
                      ? 'bg-surface-container-high text-primary font-medium'
                      : 'text-on-surface-variant hover:text-on-surface'
                  }`}
                  type="button"
                >
                  Reduced Noise
                </button>
              </div>
            </div>

            {/* Colored Visual Tier Band Indicator */}
            <div className="flex flex-col gap-space-xs pt-space-xs">
              <div className="flex justify-between items-center font-label-sm text-label-sm">
                <span className="text-on-surface-variant uppercase">Dynamic Risk Bands</span>
                <span className="font-mono text-outline">0.00 — 1.00 SCALE</span>
              </div>
              <div className="h-3 w-full rounded overflow-hidden flex bg-surface-container-lowest border border-outline-variant/30">
                <div
                  className="h-full bg-primary-container relative group cursor-pointer transition-all duration-150"
                  style={{ width: `${lowWidth}%` }}
                  title={`Low: 0.00 to ${medThreshold.toFixed(2)}`}
                ></div>
                <div
                  className="h-full bg-secondary-container relative group cursor-pointer transition-all duration-150"
                  style={{ width: `${medWidth}%` }}
                  title={`Medium: ${medThreshold.toFixed(2)} to ${highThreshold.toFixed(2)}`}
                ></div>
                <div
                  className="h-full bg-tertiary-container relative group cursor-pointer transition-all duration-150"
                  style={{ width: `${highWidth}%` }}
                  title={`High: ${highThreshold.toFixed(2)} to 1.00`}
                ></div>
              </div>
              <div className="flex justify-between text-xs font-label-sm text-label-sm pt-1">
                <span className="text-primary flex items-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-primary-container"></span> LOW (&lt; {medThreshold.toFixed(2)})
                </span>
                <span className="text-secondary flex items-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-secondary-container"></span> MED ({medThreshold.toFixed(2)} - {highThreshold.toFixed(2)})
                </span>
                <span className="text-tertiary flex items-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-tertiary-container"></span> HIGH (≥ {highThreshold.toFixed(2)})
                </span>
              </div>
            </div>

            {/* Sliders */}
            <div className="flex flex-col gap-space-md pt-space-xs">
              {/* Medium Threshold Slider */}
              <div className="flex flex-col gap-1.5">
                <div className="flex justify-between items-center">
                  <label className="font-label-sm text-label-sm text-on-surface uppercase" htmlFor="med-thresh">
                    Medium Risk Threshold
                  </label>
                  <span className="font-label-md text-label-md text-secondary font-mono bg-surface-container px-space-xs py-0.5 rounded border border-outline-variant/30">
                    {medThreshold.toFixed(2)}
                  </span>
                </div>
                <input
                  className="w-full accent-secondary h-1.5 bg-surface-container-high rounded-lg cursor-pointer"
                  id="med-thresh"
                  max="0.50"
                  min="0.10"
                  step="0.05"
                  type="range"
                  value={medThreshold}
                  onChange={handleMedChange}
                />
                <div className="flex justify-between font-label-sm text-label-sm text-outline">
                  <span>0.10</span>
                  <span>Current: {medThreshold.toFixed(2)}</span>
                  <span>0.50</span>
                </div>
              </div>

              {/* High Threshold Slider */}
              <div className="flex flex-col gap-1.5">
                <div className="flex justify-between items-center">
                  <label className="font-label-sm text-label-sm text-on-surface uppercase" htmlFor="high-thresh">
                    High Risk Threshold
                  </label>
                  <span className="font-label-md text-label-md text-tertiary font-mono bg-surface-container px-space-xs py-0.5 rounded border border-outline-variant/30">
                    {highThreshold.toFixed(2)}
                  </span>
                </div>
                <input
                  className="w-full accent-tertiary-container h-1.5 bg-surface-container-high rounded-lg cursor-pointer"
                  id="high-thresh"
                  max="0.85"
                  min="0.40"
                  step="0.05"
                  type="range"
                  value={highThreshold}
                  onChange={handleHighChange}
                />
                <div className="flex justify-between font-label-sm text-label-sm text-outline">
                  <span>0.40</span>
                  <span>Current: {highThreshold.toFixed(2)}</span>
                  <span>0.85</span>
                </div>
              </div>
            </div>
          </div>

          {/* Five Risk Factor Weights Calibration */}
          <div className="bg-surface rounded-xl p-space-lg shadow-sm flex flex-col gap-space-md border border-outline-variant/30">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-space-sm">
                <span className="material-symbols-outlined text-outline">balance</span>
                <h2 className="font-headline-sm text-headline-sm text-on-surface font-semibold">
                  Factor Weight Calibration
                </h2>
              </div>
              <div className="flex items-center gap-space-xs px-space-sm py-0.5 rounded bg-surface-container-high border border-outline-variant/30">
                <span className={`w-2 h-2 rounded-full ${isNormalized ? 'bg-primary-container' : 'bg-secondary'}`}></span>
                <span className={`font-label-sm text-label-sm font-mono font-medium ${isNormalized ? 'text-primary' : 'text-secondary'}`}>
                  {totalWeights}% {isNormalized ? '(Normalized)' : '(Unbalanced)'}
                </span>
              </div>
            </div>
            <p className="font-body-sm text-body-sm text-on-surface-variant">
              Adjust neural network multi-heuristic scoring tensors for local runway topography.
            </p>

            <div className="flex flex-col gap-space-sm">
              {/* Weight 1 */}
              <div className="flex flex-col gap-1">
                <div className="flex justify-between items-center font-label-sm text-label-sm">
                  <span className="text-on-surface">Runway Proximity</span>
                  <span className="text-primary font-mono">{weights.w1}%</span>
                </div>
                <input
                  className="w-full accent-primary h-1.5 bg-surface-container-high rounded cursor-pointer"
                  max="60"
                  min="5"
                  type="range"
                  value={weights.w1}
                  onChange={(e) => handleWeightChange('w1', e.target.value)}
                />
              </div>

              {/* Weight 2 */}
              <div className="flex flex-col gap-1">
                <div className="flex justify-between items-center font-label-sm text-label-sm">
                  <span className="text-on-surface">Bird Count (Target Volume)</span>
                  <span className="text-on-surface-variant font-mono">{weights.w2}%</span>
                </div>
                <input
                  className="w-full accent-on-surface-variant h-1.5 bg-surface-container-high rounded cursor-pointer"
                  max="50"
                  min="5"
                  type="range"
                  value={weights.w2}
                  onChange={(e) => handleWeightChange('w2', e.target.value)}
                />
              </div>

              {/* Weight 3 */}
              <div className="flex flex-col gap-1">
                <div className="flex justify-between items-center font-label-sm text-label-sm">
                  <span className="text-on-surface">Flock Biomass Estimation</span>
                  <span className="text-on-surface-variant font-mono">{weights.w3}%</span>
                </div>
                <input
                  className="w-full accent-on-surface-variant h-1.5 bg-surface-container-high rounded cursor-pointer"
                  max="50"
                  min="5"
                  type="range"
                  value={weights.w3}
                  onChange={(e) => handleWeightChange('w3', e.target.value)}
                />
              </div>

              {/* Weight 4 */}
              <div className="flex flex-col gap-1">
                <div className="flex justify-between items-center font-label-sm text-label-sm">
                  <span className="text-on-surface">Speed &amp; Velocity Trajectory</span>
                  <span className="text-on-surface-variant font-mono">{weights.w4}%</span>
                </div>
                <input
                  className="w-full accent-on-surface-variant h-1.5 bg-surface-container-high rounded cursor-pointer"
                  max="40"
                  min="5"
                  type="range"
                  value={weights.w4}
                  onChange={(e) => handleWeightChange('w4', e.target.value)}
                />
              </div>

              {/* Weight 5 */}
              <div className="flex flex-col gap-1">
                <div className="flex justify-between items-center font-label-sm text-label-sm">
                  <span className="text-on-surface">Time-of-Day Diurnal Factor</span>
                  <span className="text-on-surface-variant font-mono">{weights.w5}%</span>
                </div>
                <input
                  className="w-full accent-on-surface-variant h-1.5 bg-surface-container-high rounded cursor-pointer"
                  max="30"
                  min="0"
                  type="range"
                  value={weights.w5}
                  onChange={(e) => handleWeightChange('w5', e.target.value)}
                />
              </div>
            </div>
          </div>

          {/* ATC Notification & Dispatcher Settings */}
          <div className="bg-surface rounded-xl p-space-lg shadow-sm flex flex-col gap-space-md border border-outline-variant/30">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-space-sm">
                <span className="material-symbols-outlined text-outline">podcasts</span>
                <h2 className="font-headline-sm text-headline-sm text-on-surface font-semibold">
                  ATC Alert Dispatch Protocol
                </h2>
              </div>
              <span className="material-symbols-outlined text-primary text-sm">wifi_tethering</span>
            </div>

            <div className="flex flex-col gap-space-md">
              {/* Intercom Audio Toggle */}
              <div className="flex items-center justify-between py-space-xs">
                <div className="flex flex-col">
                  <span className="font-body-md text-body-md text-on-surface font-medium">
                    Automated Intercom Audio Warning
                  </span>
                  <span className="font-body-sm text-body-sm text-on-surface-variant">
                    Broadcast synthesised chime &amp; azimuth over tower bus
                  </span>
                </div>
                <label className="relative inline-flex items-center cursor-pointer">
                  <input
                    checked={audioAlertEnabled}
                    onChange={(e) => setAudioAlertEnabled(e.target.checked)}
                    className="sr-only peer"
                    type="checkbox"
                  />
                  <div className="w-11 h-6 bg-surface-container-high peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-primary-container"></div>
                </label>
              </div>

              {/* ATC Telemetry Connection Interface */}
              <div className="flex items-center justify-between py-space-xs">
                <div className="flex flex-col">
                  <span className="font-body-md text-body-md text-on-surface font-medium">
                    ATC Gateway Integration
                  </span>
                  <span className="font-body-sm text-body-sm text-on-surface-variant">
                    AFTN / AMHS standard dispatch link
                  </span>
                </div>
                <div className="flex items-center gap-1.5 bg-surface-container px-space-sm py-1 rounded border border-outline-variant/30">
                  <span className="w-2 h-2 rounded-full bg-primary-container animate-ping"></span>
                  <span className="font-label-sm text-label-sm text-primary uppercase font-mono">CONNECTED</span>
                </div>
              </div>

              {/* Cooldown Period Stepper */}
              <div className="flex items-center justify-between py-space-xs">
                <div className="flex flex-col">
                  <span className="font-body-md text-body-md text-on-surface font-medium">
                    Repeat Alert Cooldown
                  </span>
                  <span className="font-body-sm text-body-sm text-on-surface-variant">
                    Suppresses redundant alerts for single tracked flock
                  </span>
                </div>
                <div className="flex items-center gap-space-xs bg-surface-container rounded px-space-sm py-1 border border-outline-variant/30">
                  <button
                    onClick={() => setCooldownSeconds(prev => Math.max(15, prev - 15))}
                    className="text-outline hover:text-on-surface cursor-pointer"
                    type="button"
                  >
                    <span className="material-symbols-outlined text-sm">remove</span>
                  </button>
                  <span className="font-label-md text-label-md text-on-surface font-mono font-medium px-space-xs">
                    {cooldownSeconds}s
                  </span>
                  <button
                    onClick={() => setCooldownSeconds(prev => Math.min(180, prev + 15))}
                    className="text-outline hover:text-on-surface cursor-pointer"
                    type="button"
                  >
                    <span className="material-symbols-outlined text-sm">add</span>
                  </button>
                </div>
              </div>
            </div>

            <div className="pt-space-xs">
              <button
                onClick={handleTestDispatch}
                className="w-full h-9 bg-surface-container-high hover:bg-surface-variant text-on-surface rounded font-label-md text-label-md font-medium transition-colors flex items-center justify-center gap-space-xs cursor-pointer border border-outline-variant/30"
                type="button"
              >
                <span className="material-symbols-outlined text-sm">send</span>
                <span>Broadcast Test Dispatch (Dry Run)</span>
              </button>
            </div>

            {testDispatchStatus && (
              <div className="px-space-md py-1.5 bg-primary/10 border border-primary/30 rounded text-primary font-label-sm text-label-sm flex items-center gap-2">
                <span className="material-symbols-outlined text-sm">check_circle</span>
                <span>{testDispatchStatus}</span>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

