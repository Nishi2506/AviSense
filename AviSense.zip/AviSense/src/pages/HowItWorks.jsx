import React from 'react';
import { useApp } from '../context/AppContext';
import './HowItWorks.css';

export default function HowItWorks() {
  const { medThreshold, highThreshold, weights } = useApp();

  return (
    <div className="flex flex-col w-full gap-space-xl pb-space-xl how-it-works-container">
      {/* SECTION 1: HEADER & SYSTEM OVERVIEW BRIEF */}
      <section className="flex flex-col gap-space-sm">
        <div className="flex items-center gap-space-sm">
          <span className="font-label-sm text-label-sm text-primary uppercase tracking-widest px-2 py-0.5 rounded-DEFAULT bg-surface-container-low border border-primary/20">
            Methodology &amp; Architecture
          </span>
          <span className="font-label-sm text-label-sm text-on-surface-variant/40 tracking-widest">
            SPEC-REV 2.4.9
          </span>
        </div>
        <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-space-md">
          <div>
            <h2 className="font-headline-xl text-headline-xl text-on-surface tracking-tight font-semibold">
              How It Works
            </h2>
            <p className="font-body-md text-body-md text-on-surface-variant max-w-3xl mt-1">
              End-to-end operational pipeline from optical runway surveillance to automated risk scoring and telemetry alert dispatch.
            </p>
          </div>
          <div className="flex items-center gap-space-sm">
            <div className="px-space-md py-2 rounded-DEFAULT bg-surface-container border border-surface-bright flex items-center gap-space-sm">
              <span className="material-symbols-outlined text-primary text-[18px]">verified</span>
              <span className="font-label-sm text-label-sm text-on-surface uppercase tracking-wider">
                ICAO DOC 9137 COMPLIANT
              </span>
            </div>
          </div>
        </div>
      </section>

      {/* SECTION 2: SYSTEM ARCHITECTURE PIPELINE (5 Progressive Connected Stages) */}
      <section className="flex flex-col gap-space-md">
        <div className="flex items-center justify-between border-b border-surface-bright/40 pb-space-xs">
          <div className="flex items-center gap-space-xs">
            <span className="font-label-sm text-label-sm text-primary font-semibold">01</span>
            <span className="font-label-sm text-label-sm text-on-surface uppercase tracking-wider font-semibold">
              Architecture Pipeline
            </span>
            <span className="text-on-surface-variant/40">/</span>
            <span className="font-label-sm text-label-sm text-on-surface-variant">
              Frame Ingest to Decision Logic
            </span>
          </div>
          <span className="font-label-sm text-label-sm text-on-surface-variant/60">
            LATENCY BENCHMARK: &lt; 42ms REAL-TIME
          </span>
        </div>

        {/* Connected Pipeline Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-space-sm relative">
          {/* Stage 01 */}
          <div className="flex flex-col justify-between p-space-md bg-surface-container rounded-DEFAULT border border-surface-bright/60 hover:border-primary/40 transition-colors relative">
            <div className="flex flex-col gap-space-sm">
              <div className="flex items-center justify-between">
                <span className="font-label-sm text-label-sm text-primary font-semibold px-2 py-0.5 rounded-DEFAULT bg-surface-container-low border border-primary/20">
                  STAGE 01
                </span>
                <span className="material-symbols-outlined text-primary text-[18px]">videocam</span>
              </div>
              <div>
                <h3 className="font-headline-sm text-headline-sm text-on-surface font-medium tracking-tight">Video Input Ingest</h3>
                <p className="font-body-sm text-body-sm text-on-surface-variant mt-1.5 leading-relaxed">
                  High-throughput RTSP/H.264 camera feeds ingested at 60 FPS across active threshold zones.
                </p>
              </div>
              <div className="flex flex-col gap-1 pt-1 border-t border-surface-bright/40 font-label-sm text-label-sm">
                <div className="flex items-center justify-between text-on-surface-variant/70">
                  <span className="uppercase">Input:</span> <span className="text-on-surface font-medium truncate">4K RTSP Feeds</span>
                </div>
                <div className="flex items-center justify-between text-on-surface-variant/70">
                  <span className="uppercase">Output:</span> <span className="text-primary font-medium truncate">Raw NV12 Frames</span>
                </div>
              </div>
            </div>
            <div className="mt-space-md pt-space-xs border-t border-surface-bright/40 flex items-center justify-between text-label-sm font-label-sm text-on-surface-variant/60">
              <span>LATENCY: 8ms</span>
              <span className="material-symbols-outlined text-[16px] text-primary">arrow_forward</span>
            </div>
          </div>

          {/* Stage 02 */}
          <div className="flex flex-col justify-between p-space-md bg-surface-container rounded-DEFAULT border border-surface-bright/60 hover:border-primary/40 transition-colors relative">
            <div className="flex flex-col gap-space-sm">
              <div className="flex items-center justify-between">
                <span className="font-label-sm text-label-sm text-primary font-semibold px-2 py-0.5 rounded-DEFAULT bg-surface-container-low border border-primary/20">
                  STAGE 02
                </span>
                <span className="material-symbols-outlined text-primary text-[18px]">filter_center_focus</span>
              </div>
              <div>
                <h3 className="font-headline-sm text-headline-sm text-on-surface font-medium tracking-tight">Avian Detection</h3>
                <p className="font-body-sm text-body-sm text-on-surface-variant mt-1.5 leading-relaxed">
                  YOLO-based neural inference isolates avian silhouettes from cloud noise, heat shimmers, and ground vehicles.
                </p>
              </div>
              <div className="flex flex-col gap-1 pt-1 border-t border-surface-bright/40 font-label-sm text-label-sm">
                <div className="flex items-center justify-between text-on-surface-variant/70">
                  <span className="uppercase">Input:</span> <span className="text-on-surface font-medium truncate">Raw NV12 Frames</span>
                </div>
                <div className="flex items-center justify-between text-on-surface-variant/70">
                  <span className="uppercase">Output:</span> <span className="text-primary font-medium truncate">Bounding Boxes</span>
                </div>
              </div>
            </div>
            <div className="mt-space-md pt-space-xs border-t border-surface-bright/40 flex items-center justify-between text-label-sm font-label-sm text-on-surface-variant/60">
              <span>LATENCY: 14ms</span>
              <span className="material-symbols-outlined text-primary text-[16px]">arrow_forward</span>
            </div>
          </div>

          {/* Stage 03 */}
          <div className="flex flex-col justify-between p-space-md bg-surface-container rounded-DEFAULT border border-surface-bright/60 hover:border-primary/40 transition-colors relative">
            <div className="flex flex-col gap-space-sm">
              <div className="flex items-center justify-between">
                <span className="font-label-sm text-label-sm text-primary font-semibold px-2 py-0.5 rounded-DEFAULT bg-surface-container-low border border-primary/20">
                  STAGE 03
                </span>
                <span className="material-symbols-outlined text-primary text-[18px]">timeline</span>
              </div>
              <div>
                <h3 className="font-headline-sm text-headline-sm text-on-surface font-medium tracking-tight">Multi-Target Tracking</h3>
                <p className="font-body-sm text-body-sm text-on-surface-variant mt-1.5 leading-relaxed">
                  DeepSORT spatial association maintains persistent trajectories, Kalman filter velocities, and target IDs.
                </p>
              </div>
              <div className="flex flex-col gap-1 pt-1 border-t border-surface-bright/40 font-label-sm text-label-sm">
                <div className="flex items-center justify-between text-on-surface-variant/70">
                  <span className="uppercase">Input:</span> <span className="text-on-surface font-medium truncate">Bounding Boxes</span>
                </div>
                <div className="flex items-center justify-between text-on-surface-variant/70">
                  <span className="uppercase">Output:</span> <span className="text-primary font-medium truncate">Track Vectors</span>
                </div>
              </div>
            </div>
            <div className="mt-space-md pt-space-xs border-t border-surface-bright/40 flex items-center justify-between text-label-sm font-label-sm text-on-surface-variant/60">
              <span>LATENCY: 7ms</span>
              <span className="material-symbols-outlined text-primary text-[16px]">arrow_forward</span>
            </div>
          </div>

          {/* Stage 04 */}
          <div className="flex flex-col justify-between p-space-md bg-surface-container rounded-DEFAULT border border-surface-bright/60 hover:border-primary/40 transition-colors relative">
            <div className="flex flex-col gap-space-sm">
              <div className="flex items-center justify-between">
                <span className="font-label-sm text-label-sm text-primary font-semibold px-2 py-0.5 rounded-DEFAULT bg-surface-container-low border border-primary/20">
                  STAGE 04
                </span>
                <span className="material-symbols-outlined text-primary text-[18px]">analytics</span>
              </div>
              <div>
                <h3 className="font-headline-sm text-headline-sm text-on-surface font-medium tracking-tight">Feature Extraction</h3>
                <p className="font-body-sm text-body-sm text-on-surface-variant mt-1.5 leading-relaxed">
                  Normalizes target distance to centerline, target counts, flock density, approach speed, and diurnal weight.
                </p>
              </div>
              <div className="flex flex-col gap-1 pt-1 border-t border-surface-bright/40 font-label-sm text-label-sm">
                <div className="flex items-center justify-between text-on-surface-variant/70">
                  <span className="uppercase">Input:</span> <span className="text-on-surface font-medium truncate">Track Vectors</span>
                </div>
                <div className="flex items-center justify-between text-on-surface-variant/70">
                  <span className="uppercase">Output:</span> <span className="text-primary font-medium truncate">5 Normalized Factors</span>
                </div>
              </div>
            </div>
            <div className="mt-space-md pt-space-xs border-t border-surface-bright/40 flex items-center justify-between text-label-sm font-label-sm text-on-surface-variant/60">
              <span>LATENCY: 5ms</span>
              <span className="material-symbols-outlined text-primary text-[16px]">arrow_forward</span>
            </div>
          </div>

          {/* Stage 05 */}
          <div className="flex flex-col justify-between p-space-md bg-surface-container rounded-DEFAULT border border-surface-bright/60 hover:border-primary/40 transition-colors relative">
            <div className="flex flex-col gap-space-sm">
              <div className="flex items-center justify-between">
                <span className="font-label-sm text-label-sm text-primary font-semibold px-2 py-0.5 rounded-DEFAULT bg-surface-container-low border border-primary/20">
                  STAGE 05
                </span>
                <span className="material-symbols-outlined text-primary text-[18px]">crisis_alert</span>
              </div>
              <div>
                <h3 className="font-headline-sm text-headline-sm text-on-surface font-medium tracking-tight">Scoring &amp; Dispatch</h3>
                <p className="font-body-sm text-body-sm text-on-surface-variant mt-1.5 leading-relaxed">
                  Weighted multi-variable synthesis generates instant risk index and triggers automated ATC broadcast.
                </p>
              </div>
              <div className="flex flex-col gap-1 pt-1 border-t border-surface-bright/40 font-label-sm text-label-sm">
                <div className="flex items-center justify-between text-on-surface-variant/70">
                  <span className="uppercase">Input:</span> <span className="text-on-surface font-medium truncate">5 Normalized Factors</span>
                </div>
                <div className="flex items-center justify-between text-on-surface-variant/70">
                  <span className="uppercase">Output:</span> <span className="text-primary font-medium truncate">Active Alert Payload</span>
                </div>
              </div>
            </div>
            <div className="mt-space-md pt-space-xs border-t border-surface-bright/40 flex items-center justify-between text-label-sm font-label-sm text-on-surface-variant/60">
              <span>LATENCY: 4ms</span>
              <span className="material-symbols-outlined text-primary text-[16px]">done_all</span>
            </div>
          </div>
        </div>
      </section>

      {/* SECTION 3: THE FIVE EVALUATED RISK FACTORS */}
      <section className="flex flex-col gap-space-md">
        <div className="flex items-center justify-between border-b border-surface-bright/40 pb-space-xs">
          <div className="flex items-center gap-space-xs">
            <span className="font-label-sm text-label-sm text-primary font-semibold">02</span>
            <span className="font-label-sm text-label-sm text-on-surface uppercase tracking-wider font-semibold">
              Evaluated Risk Factors
            </span>
            <span className="text-on-surface-variant/40">/</span>
            <span className="font-label-sm text-label-sm text-on-surface-variant">Real-Time Threat Variables</span>
          </div>
          <span className="font-label-sm text-label-sm text-on-surface-variant/60">WEIGHTED LINEAR MODEL</span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-space-sm">
          {/* Factor 01 */}
          <div className="flex flex-col justify-between p-space-md bg-surface-container rounded-DEFAULT border border-surface-bright/60">
            <div className="flex flex-col gap-space-sm">
              <div className="flex items-center justify-between">
                <span className="font-label-sm text-label-sm text-on-surface-variant font-semibold">FACTOR 01</span>
                <span className="font-label-sm text-label-sm text-primary font-semibold">{weights.w1}% WEIGHT</span>
              </div>
              <div className="w-full h-1.5 bg-[#242828] rounded-full overflow-hidden">
                <div className="bg-primary h-full" style={{ width: `${weights.w1}%` }}></div>
              </div>
              <div>
                <h4 className="font-headline-sm text-headline-sm text-on-surface font-medium">Runway Proximity</h4>
                <p className="font-body-sm text-body-sm text-on-surface-variant mt-1.5 leading-relaxed">
                  Geometric orthogonal distance from target position to the active runway centerline and runway safety zone boundaries.
                </p>
              </div>
              <div className="bg-surface-container-low p-2 rounded-DEFAULT border border-surface-bright/40 flex flex-col gap-0.5 font-label-sm text-label-sm">
                <span className="text-on-surface-variant/70 uppercase">Formula Logic</span>
                <span className="text-on-surface font-metric-display-mobile text-[12px]">P = clamp(1 - (d / 500m), 0, 1)</span>
              </div>
            </div>
            <div className="mt-space-md pt-space-xs border-t border-surface-bright/40">
              <span className="font-label-sm text-label-sm text-on-surface-variant/70 uppercase block">Impact Behavior</span>
              <p className="font-body-sm text-body-sm text-on-surface mt-1">
                Exponential risk escalation when targets breach the 150m safety margin.
              </p>
            </div>
          </div>

          {/* Factor 02 */}
          <div className="flex flex-col justify-between p-space-md bg-surface-container rounded-DEFAULT border border-surface-bright/60">
            <div className="flex flex-col gap-space-sm">
              <div className="flex items-center justify-between">
                <span className="font-label-sm text-label-sm text-on-surface-variant font-semibold">FACTOR 02</span>
                <span className="font-label-sm text-label-sm text-primary font-semibold">{weights.w2}% WEIGHT</span>
              </div>
              <div className="w-full h-1.5 bg-[#242828] rounded-full overflow-hidden">
                <div className="bg-primary h-full" style={{ width: `${weights.w2}%` }}></div>
              </div>
              <div>
                <h4 className="font-headline-sm text-headline-sm text-on-surface font-medium">Bird Count</h4>
                <p className="font-body-sm text-body-sm text-on-surface-variant mt-1.5 leading-relaxed">
                  Total validated individual avian targets concurrently tracked within the sensor's active runway sector FOV.
                </p>
              </div>
              <div className="bg-surface-container-low p-2 rounded-DEFAULT border border-surface-bright/40 flex flex-col gap-0.5 font-label-sm text-label-sm">
                <span className="text-on-surface-variant/70 uppercase">Formula Logic</span>
                <span className="text-on-surface font-metric-display-mobile text-[12px]">C = clamp(n_birds / 15, 0, 1)</span>
              </div>
            </div>
            <div className="mt-space-md pt-space-xs border-t border-surface-bright/40">
              <span className="font-label-sm text-label-sm text-on-surface-variant/70 uppercase block">Impact Behavior</span>
              <p className="font-body-sm text-body-sm text-on-surface mt-1">
                Scales linearly with count, compounding with proximity factor.
              </p>
            </div>
          </div>

          {/* Factor 03 */}
          <div className="flex flex-col justify-between p-space-md bg-surface-container rounded-DEFAULT border border-surface-bright/60">
            <div className="flex flex-col gap-space-sm">
              <div className="flex items-center justify-between">
                <span className="font-label-sm text-label-sm text-on-surface-variant font-semibold">FACTOR 03</span>
                <span className="font-label-sm text-label-sm text-primary font-semibold">{weights.w3}% WEIGHT</span>
              </div>
              <div className="w-full h-1.5 bg-[#242828] rounded-full overflow-hidden">
                <div className="bg-primary h-full" style={{ width: `${weights.w3}%` }}></div>
              </div>
              <div>
                <h4 className="font-headline-sm text-headline-sm text-on-surface font-medium">Flock Biomass</h4>
                <p className="font-body-sm text-body-sm text-on-surface-variant mt-1.5 leading-relaxed">
                  Estimated cumulative mass and cluster volume of birds demonstrating collective, synchronized flight behavior.
                </p>
              </div>
              <div className="bg-surface-container-low p-2 rounded-DEFAULT border border-surface-bright/40 flex flex-col gap-0.5 font-label-sm text-label-sm">
                <span className="text-on-surface-variant/70 uppercase">Formula Logic</span>
                <span className="text-on-surface font-metric-display-mobile text-[12px]">B = clamp(Σ(mass_est) / 10kg, 0, 1)</span>
              </div>
            </div>
            <div className="mt-space-md pt-space-xs border-t border-surface-bright/40">
              <span className="font-label-sm text-label-sm text-on-surface-variant/70 uppercase block">Impact Behavior</span>
              <p className="font-body-sm text-body-sm text-on-surface mt-1">
                Engine ingestion damage potential non-linearly increases with mass.
              </p>
            </div>
          </div>

          {/* Factor 04 */}
          <div className="flex flex-col justify-between p-space-md bg-surface-container rounded-DEFAULT border border-surface-bright/60">
            <div className="flex flex-col gap-space-sm">
              <div className="flex items-center justify-between">
                <span className="font-label-sm text-label-sm text-on-surface-variant font-semibold">FACTOR 04</span>
                <span className="font-label-sm text-label-sm text-primary font-semibold">{weights.w4}% WEIGHT</span>
              </div>
              <div className="w-full h-1.5 bg-[#242828] rounded-full overflow-hidden">
                <div className="bg-primary h-full" style={{ width: `${weights.w4}%` }}></div>
              </div>
              <div>
                <h4 className="font-headline-sm text-headline-sm text-on-surface font-medium">Speed &amp; Trajectory</h4>
                <p className="font-body-sm text-body-sm text-on-surface-variant mt-1.5 leading-relaxed">
                  Relative velocity vector and angular closure rate calculated relative to inbound aircraft glideslope.
                </p>
              </div>
              <div className="bg-surface-container-low p-2 rounded-DEFAULT border border-surface-bright/40 flex flex-col gap-0.5 font-label-sm text-label-sm">
                <span className="text-on-surface-variant/70 uppercase">Formula Logic</span>
                <span className="text-on-surface font-metric-display-mobile text-[12px]">V = (vel / 40kts) × cos(θ_closure)</span>
              </div>
            </div>
            <div className="mt-space-md pt-space-xs border-t border-surface-bright/40">
              <span className="font-label-sm text-label-sm text-on-surface-variant/70 uppercase block">Impact Behavior</span>
              <p className="font-body-sm text-body-sm text-on-surface mt-1">
                Direct perpendicular flight across centerline triggers maximum multiplier.
              </p>
            </div>
          </div>

          {/* Factor 05 */}
          <div className="flex flex-col justify-between p-space-md bg-surface-container rounded-DEFAULT border border-surface-bright/60">
            <div className="flex flex-col gap-space-sm">
              <div className="flex items-center justify-between">
                <span className="font-label-sm text-label-sm text-on-surface-variant font-semibold">FACTOR 05</span>
                <span className="font-label-sm text-label-sm text-primary font-semibold">{weights.w5}% WEIGHT</span>
              </div>
              <div className="w-full h-1.5 bg-[#242828] rounded-full overflow-hidden">
                <div className="bg-primary h-full" style={{ width: `${weights.w5}%` }}></div>
              </div>
              <div>
                <h4 className="font-headline-sm text-headline-sm text-on-surface font-medium">Time of Day</h4>
                <p className="font-body-sm text-body-sm text-on-surface-variant mt-1.5 leading-relaxed">
                  Solar diurnal cycle coefficient accounting for heightened crepuscular feeding and migratory flights.
                </p>
              </div>
              <div className="bg-surface-container-low p-2 rounded-DEFAULT border border-surface-bright/40 flex flex-col gap-0.5 font-label-sm text-label-sm">
                <span className="text-on-surface-variant/70 uppercase">Formula Logic</span>
                <span className="text-on-surface font-metric-display-mobile text-[12px]">T = 0.85 (Dawn/Dusk) | 0.30 (Day/Night)</span>
              </div>
            </div>
            <div className="mt-space-md pt-space-xs border-t border-surface-bright/40">
              <span className="font-label-sm text-label-sm text-on-surface-variant/70 uppercase block">Impact Behavior</span>
              <p className="font-body-sm text-body-sm text-on-surface mt-1">
                Dawn (+0.12) and dusk (+0.15) baseline risk offsets dynamically applied.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* SECTION 4: RISK SCORING CLASSIFICATION PROTOCOL (3 Tiers Matrix) */}
      <section className="flex flex-col gap-space-md">
        <div className="flex items-center justify-between border-b border-surface-bright/40 pb-space-xs">
          <div className="flex items-center gap-space-xs">
            <span className="font-label-sm text-label-sm text-primary font-semibold">03</span>
            <span className="font-label-sm text-label-sm text-on-surface uppercase tracking-wider font-semibold">
              Risk Classification Protocol
            </span>
            <span className="text-on-surface-variant/40">/</span>
            <span className="font-label-sm text-label-sm text-on-surface-variant">Automated Action Thresholds</span>
          </div>
          <div className="flex items-center gap-space-md">
            <div className="flex items-center gap-1.5 font-label-sm text-label-sm">
              <span className="text-on-surface-variant/80">MED:</span>
              <span className="text-secondary font-semibold">{medThreshold.toFixed(2)}</span>
            </div>
            <div className="flex items-center gap-1.5 font-label-sm text-label-sm">
              <span className="text-on-surface-variant/80">HIGH:</span>
              <span className="text-tertiary-container font-semibold">{highThreshold.toFixed(2)}</span>
            </div>
          </div>
        </div>

        {/* 3 Tier Cards */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-space-md">
          {/* Tier 1: Low Risk */}
          <div className="flex flex-col justify-between p-space-lg bg-surface-container rounded-DEFAULT border border-surface-bright/60 relative overflow-hidden">
            <div className="absolute top-0 left-0 right-0 h-1 bg-primary"></div>
            <div className="flex flex-col gap-space-md">
              <div className="flex items-center justify-between">
                <span className="font-label-sm text-label-sm text-primary uppercase font-semibold tracking-wider">
                  INDEX &lt; {medThreshold.toFixed(2)}
                </span>
                <span className="px-2 py-0.5 text-label-sm font-label-sm rounded-DEFAULT bg-on-primary-container text-primary border border-primary/30 uppercase font-medium">
                  Nominal Operations
                </span>
              </div>
              <div>
                <h4 className="font-headline-lg text-headline-lg text-on-surface font-semibold tracking-tight">Low Risk Tier</h4>
                <p className="font-body-sm text-body-sm text-on-surface-variant mt-2 leading-relaxed">
                  Distant perimeter movements, solitary avian targets, or stable activity safely divergent from active take-off and landing corridors.
                </p>
              </div>
              <div className="flex flex-col gap-space-xs pt-space-xs border-t border-surface-bright/40">
                <span className="font-label-sm text-label-sm text-on-surface-variant/70 uppercase">Operational Thresholds</span>
                <ul className="font-body-sm text-body-sm text-on-surface flex flex-col gap-1 list-none p-0 m-0">
                  <li className="flex items-center gap-2"><span className="material-symbols-outlined text-primary text-[14px]">check_circle</span> Centerline proximity &gt; 350m</li>
                  <li className="flex items-center gap-2"><span className="material-symbols-outlined text-primary text-[14px]">check_circle</span> Target count 1 – 3 birds</li>
                  <li className="flex items-center gap-2"><span className="material-symbols-outlined text-primary text-[14px]">check_circle</span> Velocity &lt; 15 kts, heading divergent</li>
                </ul>
              </div>
            </div>
            <div className="mt-space-lg pt-space-sm border-t border-surface-bright/40 flex items-center justify-between">
              <span className="font-label-sm text-label-sm text-on-surface-variant uppercase">Operator Protocol</span>
              <span className="font-label-sm text-label-sm text-primary font-medium flex items-center gap-1">
                <span className="material-symbols-outlined text-[16px]">visibility</span> Passive Auto-Logging
              </span>
            </div>
          </div>

          {/* Tier 2: Medium Risk */}
          <div className="flex flex-col justify-between p-space-lg bg-surface-container rounded-DEFAULT border border-surface-bright/60 relative overflow-hidden">
            <div className="absolute top-0 left-0 right-0 h-1 bg-secondary"></div>
            <div className="flex flex-col gap-space-md">
              <div className="flex items-center justify-between">
                <span className="font-label-sm text-label-sm text-secondary uppercase font-semibold tracking-wider">
                  INDEX {medThreshold.toFixed(2)} – {highThreshold.toFixed(2)}
                </span>
                <span className="px-2 py-0.5 text-label-sm font-label-sm rounded-DEFAULT bg-on-secondary/30 text-secondary border border-secondary/40 uppercase font-medium">
                  Elevated Vigilance
                </span>
              </div>
              <div>
                <h4 className="font-headline-lg text-headline-lg text-on-surface font-semibold tracking-tight">Medium Risk Tier</h4>
                <p className="font-body-sm text-body-sm text-on-surface-variant mt-2 leading-relaxed">
                  Flocks approaching outer obstacle assessment boundaries, stationary clusters near taxiways, or converging flight patterns.
                </p>
              </div>
              <div className="flex flex-col gap-space-xs pt-space-xs border-t border-surface-bright/40">
                <span className="font-label-sm text-label-sm text-on-surface-variant/70 uppercase">Operational Thresholds</span>
                <ul className="font-body-sm text-body-sm text-on-surface flex flex-col gap-1 list-none p-0 m-0">
                  <li className="flex items-center gap-2"><span className="material-symbols-outlined text-secondary text-[14px]">warning</span> Centerline proximity 150m – 350m</li>
                  <li className="flex items-center gap-2"><span className="material-symbols-outlined text-secondary text-[14px]">warning</span> Flock group 4 – 12 birds</li>
                  <li className="flex items-center gap-2"><span className="material-symbols-outlined text-secondary text-[14px]">warning</span> Parallel trajectory or loitering</li>
                </ul>
              </div>
            </div>
            <div className="mt-space-lg pt-space-sm border-t border-surface-bright/40 flex items-center justify-between">
              <span className="font-label-sm text-label-sm text-on-surface-variant uppercase">Operator Protocol</span>
              <span className="font-label-sm text-label-sm text-secondary font-medium flex items-center gap-1">
                <span className="material-symbols-outlined text-[16px]">track_changes</span> Advisory &amp; Camera Auto-Lock
              </span>
            </div>
          </div>

          {/* Tier 3: High Risk */}
          <div className="flex flex-col justify-between p-space-lg bg-surface-container rounded-DEFAULT border border-surface-bright/60 relative overflow-hidden">
            <div className="absolute top-0 left-0 right-0 h-1 bg-tertiary-container"></div>
            <div className="flex flex-col gap-space-md">
              <div className="flex items-center justify-between">
                <span className="font-label-sm text-label-sm text-tertiary-container uppercase font-semibold tracking-wider">
                  INDEX ≥ {highThreshold.toFixed(2)}
                </span>
                <span className="px-2 py-0.5 text-label-sm font-label-sm rounded-DEFAULT bg-on-tertiary-container/30 text-tertiary-container border border-tertiary-container/40 uppercase font-medium">
                  Critical Alert
                </span>
              </div>
              <div>
                <h4 className="font-headline-lg text-headline-lg text-on-surface font-semibold tracking-tight">High Risk Tier</h4>
                <p className="font-body-sm text-body-sm text-on-surface-variant mt-2 leading-relaxed">
                  Direct runway breach, dense flock biomass traversing touchdown zones, or high-speed intercept trajectory with active departure or approach slot.
                </p>
              </div>
              <div className="flex flex-col gap-space-xs pt-space-xs border-t border-surface-bright/40">
                <span className="font-label-sm text-label-sm text-on-surface-variant/70 uppercase">Operational Thresholds</span>
                <ul className="font-body-sm text-body-sm text-on-surface flex flex-col gap-1 list-none p-0 m-0">
                  <li className="flex items-center gap-2"><span className="material-symbols-outlined text-tertiary-container text-[14px]">emergency</span> Centerline proximity &lt; 150m</li>
                  <li className="flex items-center gap-2"><span className="material-symbols-outlined text-tertiary-container text-[14px]">emergency</span> Dense flock (&gt; 12 birds or biomass &gt; 5kg)</li>
                  <li className="flex items-center gap-2"><span className="material-symbols-outlined text-tertiary-container text-[14px]">emergency</span> Active aircraft inbound/rollout closure</li>
                </ul>
              </div>
            </div>
            <div className="mt-space-lg pt-space-sm border-t border-surface-bright/40 flex items-center justify-between">
              <span className="font-label-sm text-label-sm text-on-surface-variant uppercase">Operator Protocol</span>
              <span className="font-label-sm text-label-sm text-tertiary-container font-semibold flex items-center gap-1">
                <span className="material-symbols-outlined text-[16px]">campaign</span> Automated Dispatch &amp; ATC Intercom
              </span>
            </div>
          </div>
        </div>
      </section>

      {/* BOTTOM METRIC SPEC SUMMARY */}
      <section className="p-space-lg bg-surface-container-low rounded-DEFAULT border border-surface-bright/40 flex flex-col gap-space-md">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-space-md border-b border-surface-bright/40 pb-space-sm">
          <div className="flex items-center gap-space-md">
            <span className="material-symbols-outlined text-primary text-[24px]">functions</span>
            <div className="flex flex-col">
              <div className="flex items-center gap-2">
                <span className="font-label-md text-label-md text-on-surface font-semibold uppercase tracking-wider">
                  Composite Risk Formula Engine
                </span>
                <span className="px-2 py-0.5 rounded-DEFAULT bg-primary/20 text-primary border border-primary/30 text-label-sm font-label-sm uppercase">
                  Dynamic Realtime
                </span>
              </div>
              <span className="font-metric-display-mobile text-body-md text-primary font-semibold mt-1 tracking-tight">
                R = ({(weights.w1 / 100).toFixed(2)} × P) + ({(weights.w2 / 100).toFixed(2)} × C) + ({(weights.w3 / 100).toFixed(2)} × B) + ({(weights.w4 / 100).toFixed(2)} × V) + ({(weights.w5 / 100).toFixed(2)} × T)
              </span>
            </div>
          </div>
          <div className="flex items-center gap-space-md text-label-sm font-label-sm text-on-surface-variant">
            <span>STANDARD: FAA AC 150/5220-25</span>
            <span className="text-surface-bright">|</span>
            <span>ICAO DOC 9137 PART 3</span>
          </div>
        </div>

        {/* Parameter Breakdown Grid */}
        <div className="grid grid-cols-2 md:grid-cols-5 gap-space-sm pt-space-xs font-label-sm text-label-sm">
          <div className="p-2.5 rounded-DEFAULT bg-surface-container border border-surface-bright/40 flex flex-col gap-1">
            <div className="flex items-center justify-between text-primary font-semibold">
              <span>P · Proximity</span>
              <span>{weights.w1}%</span>
            </div>
            <span className="text-on-surface-variant/80 text-[11px]">Runway distance factor [0.0 - 1.0]</span>
          </div>
          <div className="p-2.5 rounded-DEFAULT bg-surface-container border border-surface-bright/40 flex flex-col gap-1">
            <div className="flex items-center justify-between text-primary font-semibold">
              <span>C · Bird Count</span>
              <span>{weights.w2}%</span>
            </div>
            <span className="text-on-surface-variant/80 text-[11px]">Normalized count [0.0 - 1.0]</span>
          </div>
          <div className="p-2.5 rounded-DEFAULT bg-surface-container border border-surface-bright/40 flex flex-col gap-1">
            <div className="flex items-center justify-between text-primary font-semibold">
              <span>B · Flock Biomass</span>
              <span>{weights.w3}%</span>
            </div>
            <span className="text-on-surface-variant/80 text-[11px]">Mass &amp; density [0.0 - 1.0]</span>
          </div>
          <div className="p-2.5 rounded-DEFAULT bg-surface-container border border-surface-bright/40 flex flex-col gap-1">
            <div className="flex items-center justify-between text-primary font-semibold">
              <span>V · Trajectory</span>
              <span>{weights.w4}%</span>
            </div>
            <span className="text-on-surface-variant/80 text-[11px]">Glideslope closure [0.0 - 1.0]</span>
          </div>
          <div className="p-2.5 rounded-DEFAULT bg-surface-container border border-surface-bright/40 flex flex-col gap-1">
            <div className="flex items-center justify-between text-primary font-semibold">
              <span>T · Time of Day</span>
              <span>{weights.w5}%</span>
            </div>
            <span className="text-on-surface-variant/80 text-[11px]">Crepuscular factor [0.0 - 1.0]</span>
          </div>
        </div>
      </section>
    </div>
  );
}

