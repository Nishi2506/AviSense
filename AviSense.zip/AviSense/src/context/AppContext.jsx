import React, { createContext, useContext, useState, useEffect } from 'react';
import { CAMERA_SOURCES, EPISODES } from '../data/mockData';

const AppContext = createContext();

export function AppProvider({ children }) {
  const [selectedCameraId, setSelectedCameraId] = useState('cam-04');
  const [systemState, setSystemState] = useState('STANDBY'); // 'STANDBY' | 'CALIBRATING' | 'LIVE'
  const [calibProgress, setCalibProgress] = useState(25);
  const [calibStep, setCalibStep] = useState('CONNECTING SENSOR FEED...');
  const [liveSeconds, setLiveSeconds] = useState(14.28);
  const [feedTimerText, setFeedTimerText] = useState('00:00:14.28');
  
  // Risk Thresholds
  const [medThreshold, setMedThreshold] = useState(0.30);
  const [highThreshold, setHighThreshold] = useState(0.60);

  // Factor Weights
  const [weights, setWeights] = useState({
    w1: 35, // Runway Proximity
    w2: 20, // Bird Count
    w3: 20, // Flock Biomass
    w4: 15, // Speed & Velocity
    w5: 10  // Time of Day
  });

  // Settings toggles
  const [audioAlertEnabled, setAudioAlertEnabled] = useState(true);
  const [cooldownSeconds, setCooldownSeconds] = useState(45);
  const [selectedPreset, setSelectedPreset] = useState('standard');

  // Selected episode in Alert History
  const [selectedEpisodeId, setSelectedEpisodeId] = useState('EP-2024-089');

  // UTC Clock
  const [utcClock, setUtcClock] = useState('14:32:00 UTC');

  useEffect(() => {
    const updateClock = () => {
      const now = new Date();
      const h = String(now.getUTCHours()).padStart(2, '0');
      const m = String(now.getUTCMinutes()).padStart(2, '0');
      const s = String(now.getUTCSeconds()).padStart(2, '0');
      setUtcClock(`${h}:${m}:${s} UTC`);
    };
    updateClock();
    const interval = setInterval(updateClock, 1000);
    return () => clearInterval(interval);
  }, []);

  const selectedCamera = CAMERA_SOURCES.find(c => c.id === selectedCameraId) || CAMERA_SOURCES[0];

  // Timer for LIVE state
  useEffect(() => {
    let timer = null;
    if (systemState === 'LIVE') {
      timer = setInterval(() => {
        setLiveSeconds(prev => {
          const next = prev + 0.1;
          const mins = String(Math.floor(next / 60)).padStart(2, '0');
          const secs = String(Math.floor(next % 60)).padStart(2, '0');
          const dec = Math.floor((next % 1) * 100);
          setFeedTimerText(`00:${mins}:${secs}.${dec < 10 ? '0' + dec : dec}`);
          return next;
        });
      }, 100);
    }
    return () => {
      if (timer) clearInterval(timer);
    };
  }, [systemState]);

  const startRun = () => {
    if (systemState === 'CALIBRATING') return;
    setSystemState('CALIBRATING');
    setCalibProgress(20);
    setCalibStep('CONNECTING SENSOR FEED...');

    setTimeout(() => {
      setCalibProgress(60);
      setCalibStep(`CALIBRATING ${selectedCamera.name.toUpperCase()} BOUNDS...`);
    }, 600);

    setTimeout(() => {
      setCalibProgress(90);
      setCalibStep('ACTIVATING YOLOV8 INFERENCE ENGINE...');
    }, 1200);

    setTimeout(() => {
      setSystemState('LIVE');
      setLiveSeconds(14.28);
    }, 1800);
  };

  const stopToStandby = () => {
    setSystemState('STANDBY');
  };

  const setCamera = (camId) => {
    setSelectedCameraId(camId);
    if (systemState === 'LIVE') {
      startRun();
    }
  };

  return (
    <AppContext.Provider
      value={{
        selectedCamera,
        selectedCameraId,
        setCamera,
        systemState,
        startRun,
        stopToStandby,
        calibProgress,
        calibStep,
        liveSeconds,
        feedTimerText,
        medThreshold,
        setMedThreshold,
        highThreshold,
        setHighThreshold,
        weights,
        setWeights,
        audioAlertEnabled,
        setAudioAlertEnabled,
        cooldownSeconds,
        setCooldownSeconds,
        selectedPreset,
        setSelectedPreset,
        selectedEpisodeId,
        setSelectedEpisodeId,
        utcClock
      }}
    >
      {children}
    </AppContext.Provider>
  );
}

export function useApp() {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
}

