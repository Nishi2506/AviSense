export const CAMERA_SOURCES = [
  {
    id: 'cam-04',
    name: 'Runway 18L',
    code: '18L',
    airport: 'KDEN',
    airportName: 'Denver International Airport',
    label: 'Camera 04 - Runway 18L',
    spec: 'SENSOR: CAM-04-18L-OPTICAL-HD',
    tag: 'CAM-04 [RWY 18L]',
    grid: 'SURVEILLANCE GRID 04',
    resolution: '1920x1080@60FPS',
    latency: '<14ms',
    defaultThresh: { med: 0.30, high: 0.60 }
  },
  {
    id: 'cam-02',
    name: 'Runway 36R',
    code: '36R',
    airport: 'KDEN',
    airportName: 'Denver International Airport',
    label: 'Camera 02 - Approach North 36R',
    spec: 'SENSOR: CAM-02-36R-OPTICAL-HD',
    tag: 'CAM-02 [RWY 36R]',
    grid: 'SURVEILLANCE GRID 02',
    resolution: '1920x1080@60FPS',
    latency: '<16ms',
    defaultThresh: { med: 0.30, high: 0.60 }
  },
  {
    id: 'cam-07',
    name: 'Perimeter West',
    code: 'GLIDE-W',
    airport: 'KDEN',
    airportName: 'Denver International Airport',
    label: 'Camera 07 - Glidepath Perimeter West',
    spec: 'SENSOR: CAM-07-GLIDE-HD',
    tag: 'CAM-07 [GLIDE-W]',
    grid: 'SURVEILLANCE GRID 07',
    resolution: '1920x1080@60FPS',
    latency: '<12ms',
    defaultThresh: { med: 0.30, high: 0.60 }
  }
];

export const EPISODES = [
  {
    id: 'EP-2024-089',
    startTime: '14:15:20',
    endTime: '14:28:40',
    duration: '13m 20s',
    riskLevel: 'HIGH',
    peakScore: 0.84,
    mainDriver: 'Runway Proximity (<45m)',
    driverName: 'Runway Proximity',
    birdsTracked: 3,
    identifiedTargets: '#B-104, #B-108, #B-112',
    maxSpeed: '48.2 km/h',
    factors: {
      proximity: { value: 0.88, isPrimary: true },
      count: { value: 0.65 },
      flockSize: { value: 0.58 },
      velocity: { value: 0.52 },
      timeOfDay: { value: 0.35 }
    },
    summary: 'Flock of 3 birds entered inner approach buffer at 14:22 UTC with high closure rate toward active runway 18L. Risk peaked at 0.84 before dispersing west.'
  },
  {
    id: 'EP-2024-088',
    startTime: '13:58:10',
    endTime: '14:06:30',
    duration: '08m 20s',
    riskLevel: 'HIGH',
    peakScore: 0.76,
    mainDriver: 'Flock Size (14 Avian Units)',
    driverName: 'Flock Size',
    birdsTracked: 14,
    identifiedTargets: '#B-089 to #B-103',
    maxSpeed: '42.0 km/h',
    factors: {
      proximity: { value: 0.62 },
      count: { value: 0.82 },
      flockSize: { value: 0.89, isPrimary: true },
      velocity: { value: 0.44 },
      timeOfDay: { value: 0.35 }
    },
    summary: 'Dense migratory flock detected crossing departure corridor. Automatic advisory broadcast to Tower; birds ascended past 450ft AGL without incident.'
  },
  {
    id: 'EP-2024-087',
    startTime: '13:22:04',
    endTime: '13:30:15',
    duration: '08m 11s',
    riskLevel: 'MEDIUM',
    peakScore: 0.54,
    mainDriver: 'Speed / Velocity (40 kts)',
    driverName: 'Speed / Velocity',
    birdsTracked: 2,
    identifiedTargets: '#B-072, #B-075',
    maxSpeed: '52.4 km/h',
    factors: {
      proximity: { value: 0.45 },
      count: { value: 0.30 },
      flockSize: { value: 0.35 },
      velocity: { value: 0.78, isPrimary: true },
      timeOfDay: { value: 0.35 }
    },
    summary: 'Pair of raptors tracked at elevated speed parallel to runway 18L. Remained outside 150m critical safety margin; advisory logged passively.'
  },
  {
    id: 'EP-2024-086',
    startTime: '12:44:50',
    endTime: '12:56:02',
    duration: '11m 12s',
    riskLevel: 'HIGH',
    peakScore: 0.62,
    mainDriver: 'Bird Count (8 Units Across Centerline)',
    driverName: 'Bird Count',
    birdsTracked: 8,
    identifiedTargets: '#B-051 to #B-058',
    maxSpeed: '36.8 km/h',
    factors: {
      proximity: { value: 0.68 },
      count: { value: 0.75, isPrimary: true },
      flockSize: { value: 0.55 },
      velocity: { value: 0.41 },
      timeOfDay: { value: 0.28 }
    },
    summary: 'Dispersed cluster observed loitering near perimeter drainage sector. Breached 200m buffer momentarily before ground acoustic deterrent activation.'
  },
  {
    id: 'EP-2024-085',
    startTime: '12:10:14',
    endTime: '12:19:00',
    duration: '08m 46s',
    riskLevel: 'LOW',
    peakScore: 0.24,
    mainDriver: 'Runway Proximity (320m Perimeter)',
    driverName: 'Runway Proximity',
    birdsTracked: 1,
    identifiedTargets: '#B-042',
    maxSpeed: '18.5 km/h',
    factors: {
      proximity: { value: 0.28, isPrimary: true },
      count: { value: 0.15 },
      flockSize: { value: 0.12 },
      velocity: { value: 0.22 },
      timeOfDay: { value: 0.28 }
    },
    summary: 'Solitary bird detected on western grass verge. Divergent vector heading away from threshold. Zero operational impact.'
  },
  {
    id: 'EP-2024-084',
    startTime: '11:34:00',
    endTime: '11:42:18',
    duration: '08m 18s',
    riskLevel: 'LOW',
    peakScore: 0.18,
    mainDriver: 'Time of Day',
    driverName: 'Time of Day',
    birdsTracked: 1,
    identifiedTargets: '#B-038',
    maxSpeed: '15.0 km/h',
    factors: {
      proximity: { value: 0.18 },
      count: { value: 0.12 },
      flockSize: { value: 0.10 },
      velocity: { value: 0.14 },
      timeOfDay: { value: 0.35, isPrimary: true }
    },
    summary: 'Mid-morning solar baseline sweep. Single distant target tracked along outer perimeter fence line. Cleared.'
  },
  {
    id: 'EP-2024-083',
    startTime: '10:55:12',
    endTime: '11:04:45',
    duration: '09m 33s',
    riskLevel: 'MEDIUM',
    peakScore: 0.54,
    mainDriver: 'Speed / Velocity (44 kts)',
    driverName: 'Speed / Velocity',
    birdsTracked: 4,
    identifiedTargets: '#B-028 to #B-031',
    maxSpeed: '46.1 km/h',
    factors: {
      proximity: { value: 0.48 },
      count: { value: 0.42 },
      flockSize: { value: 0.45 },
      velocity: { value: 0.69, isPrimary: true },
      timeOfDay: { value: 0.25 }
    },
    summary: 'Small group tracked crossing runway centerline at 280ft AGL. High velocity vector triggered advisory lock; dispersed toward east retention pond.'
  },
  {
    id: 'EP-2024-082',
    startTime: '10:12:00',
    endTime: '10:18:40',
    duration: '06m 40s',
    riskLevel: 'MEDIUM',
    peakScore: 0.38,
    mainDriver: 'Bird Count (5 Units)',
    driverName: 'Bird Count',
    birdsTracked: 5,
    identifiedTargets: '#B-021 to #B-025',
    maxSpeed: '28.0 km/h',
    factors: {
      proximity: { value: 0.32 },
      count: { value: 0.55, isPrimary: true },
      flockSize: { value: 0.40 },
      velocity: { value: 0.31 },
      timeOfDay: { value: 0.25 }
    },
    summary: 'Avian flock located near taxiway Bravo intersection. Remained stationary on ground; monitored until take-off corridor cleared.'
  }
];

export const BENCHMARK_FACTORS = [
  {
    name: 'Runway Proximity / Sector Grid',
    icon: 'near_me',
    iconColor: 'text-primary',
    weight: 0.340,
    ablation: '-14.2%',
    ablationColor: 'text-error',
    variancePercent: 85,
    varianceColor: 'bg-primary',
    category: 'CAT A - CRITICAL',
    categoryClass: 'bg-error-container text-on-error-container',
    status: 'STABLE'
  },
  {
    name: 'Speed & Heading Vector',
    icon: 'speed',
    iconColor: 'text-primary',
    weight: 0.245,
    ablation: '-9.8%',
    ablationColor: 'text-error',
    variancePercent: 65,
    varianceColor: 'bg-primary',
    category: 'CAT A - CRITICAL',
    categoryClass: 'bg-error-container text-on-error-container',
    status: 'STABLE'
  },
  {
    name: 'Flock Biomass Estimation',
    icon: 'groups',
    iconColor: 'text-secondary',
    weight: 0.190,
    ablation: '-6.4%',
    ablationColor: 'text-secondary',
    variancePercent: 48,
    varianceColor: 'bg-secondary',
    category: 'CAT B - ELEVATED',
    categoryClass: 'bg-secondary-container text-on-secondary-container',
    status: 'STABLE'
  },
  {
    name: 'Avian Headcount Density',
    icon: 'pin_drop',
    iconColor: 'text-secondary',
    weight: 0.140,
    ablation: '-4.1%',
    ablationColor: 'text-secondary',
    variancePercent: 35,
    varianceColor: 'bg-secondary',
    category: 'CAT B - ELEVATED',
    categoryClass: 'bg-secondary-container text-on-secondary-container',
    status: 'STABLE'
  },
  {
    name: 'Time of Day & Sun Azimuth',
    icon: 'wb_sunny',
    iconColor: 'text-outline',
    weight: 0.085,
    ablation: '-1.7%',
    ablationColor: 'text-outline',
    variancePercent: 20,
    varianceColor: 'bg-outline',
    category: 'CAT C - MODERATE',
    categoryClass: 'bg-surface-container text-on-surface-variant',
    status: 'STABLE'
  }
];

