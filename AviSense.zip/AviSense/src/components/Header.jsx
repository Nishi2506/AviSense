import React from 'react';
import { useApp } from '../context/AppContext';

export default function Header() {
  const { selectedCamera, systemState, utcClock } = useApp();

  let pillDotClass = 'inline-block w-1.5 h-1.5 rounded-full bg-outline';
  let pillText = 'STANDBY IDLE';
  let pillBorderClass = 'border-outline-variant/30';

  if (systemState === 'CALIBRATING') {
    pillDotClass = 'inline-block w-1.5 h-1.5 rounded-full bg-secondary animate-ping';
    pillText = 'CONNECTING...';
    pillBorderClass = 'border-secondary/40';
  } else if (systemState === 'LIVE') {
    pillDotClass = 'inline-block w-1.5 h-1.5 rounded-full bg-primary animate-ping';
    pillText = 'MONITORING ACTIVE';
    pillBorderClass = 'border-primary/40';
  }

  return (
    <header className="fixed top-0 left-80 right-0 h-14 bg-surface-container-lowest/90 backdrop-blur-md border-b border-outline-variant/30 z-40 flex items-center justify-between px-gutter-desktop">
      <div className="flex items-center gap-space-md">
        <div className="flex items-center gap-2">
          <span className="material-symbols-outlined text-[18px] text-primary">flight_takeoff</span>
          <span className="font-label-md text-label-md text-on-surface tracking-wide uppercase font-semibold">
            {selectedCamera.name}
          </span>
        </div>
        <span className="text-outline-variant">|</span>
        <div className="flex items-center gap-2 font-label-md text-label-md text-on-surface-variant">
          <span className="material-symbols-outlined text-[16px]">schedule</span>
          <span>{utcClock}</span>
        </div>
      </div>
      <div className="flex items-center gap-space-md">
        <div
          className={`flex items-center gap-2 px-2.5 py-1 rounded-DEFAULT bg-surface-container border font-label-sm text-label-sm text-on-surface-variant ${pillBorderClass}`}
        >
          <span className={pillDotClass}></span>
          <span className="font-semibold text-on-surface tracking-wider">{pillText}</span>
        </div>
        <div className="w-8 h-8 rounded-full bg-primary flex items-center justify-center">
          <span className="material-symbols-outlined text-on-primary text-[18px]">person</span>
        </div>
      </div>
    </header>
  );
}

